import type { PricingRule } from "../repositories/operatorsRepo.js";

/**
 * Phase 1 pricing: deterministic rules (base + distance + time),
 * per Blueprint §10. Dynamic/predictive pricing is a Phase 2+
 * concern that needs real trip-volume data first — this is
 * intentionally simple and easy to audit.
 */
export function computeFareCents(rule: PricingRule, distanceMiles: number, durationMinutes: number): number {
  const distanceCharge = Math.round(rule.perMileCents * distanceMiles);
  const timeCharge = Math.round(rule.perMinuteCents * durationMinutes);
  const raw = rule.baseFareCents + distanceCharge + timeCharge;
  return Math.max(raw, rule.minimumFareCents);
}

import { distanceMiles } from "../lib/geo.js";
import { computeFareCents } from "./pricingEngine.js";
import { findEligibleOperators, findEligibleOperatorsForBundle } from "../repositories/operatorsRepo.js";

/**
 * The Distribution Engine — Blueprint §4.4.
 *
 * This is deliberately the ONE place that takes "a trip request +
 * a candidate pool" and returns ranked results. Phase 0 only calls
 * it from the customer quote flow (`findCandidates`), but Network
 * Mode (§5) and Corporate Mode (§6) are designed to reuse this same
 * filter + rank pipeline later with a different candidate pool and
 * distribution mode — not a second matching system.
 */

export interface QuoteCandidate {
  operatorId: string;
  operatorName: string;
  vehicleId: string;
  vehicleClass: string;
  priceCents: number;
  currency: string;
  etaMinutes: number;
  ratingAvg: number;
  onTimeRate: number | null;
  rankScore: number;
}

interface FindCandidatesInput {
  pickupLat: number;
  pickupLng: number;
  vehicleClass: string;
  serviceType: string;
}

export function findCandidates(input: FindCandidatesInput): QuoteCandidate[] {
  // 1. Hard constraints: verified operators with a service area
  // covering the pickup point and an active vehicle of the right class.
  const eligible = findEligibleOperators(input.vehicleClass, input.serviceType);

  const candidates: QuoteCandidate[] = [];

  for (const { operator, vehicle, serviceAreas, pricingRule } of eligible) {
    const coveringArea = serviceAreas.find(
      (area) => distanceMiles(area.centerLat, area.centerLng, input.pickupLat, input.pickupLng) <= area.radiusMi
    );
    if (!coveringArea) continue;

    const distanceToPickup = distanceMiles(coveringArea.centerLat, coveringArea.centerLng, input.pickupLat, input.pickupLng);
    const etaMinutes = Math.max(5, Math.round(distanceToPickup * 2.2)); // rough placeholder ETA model

    // Placeholder trip distance for fare calc — Phase 0 assumes a
    // nominal 12-mile / 25-minute trip when no dropoff is given yet
    // (real dropoff-based routing is a Google/Mapbox integration,
    // not built in this scaffold).
    const priceCents = computeFareCents(pricingRule, 12, 25);

    candidates.push({
      operatorId: operator.id,
      operatorName: operator.displayName,
      vehicleId: vehicle.id,
      vehicleClass: vehicle.vehicleClass,
      priceCents,
      currency: pricingRule.currency,
      etaMinutes,
      ratingAvg: operator.ratingAvg,
      onTimeRate: operator.onTimeRate,
      rankScore: 0,
    });
  }

  return rankCandidates(candidates);
}

/**
 * Composite ranking — Blueprint §4.2. Weighted blend of price,
 * rating, and ETA. This is intentionally simple (rule-based) per
 * the Phase 1 AI roadmap (§10); a learned ranking model comes later
 * once there's real acceptance/outcome data to train on.
 */
function rankCandidates(candidates: QuoteCandidate[]): QuoteCandidate[] {
  if (candidates.length === 0) return candidates;

  const maxPrice = Math.max(...candidates.map((c) => c.priceCents));
  const maxEta = Math.max(...candidates.map((c) => c.etaMinutes));

  const scored = candidates.map((c) => {
    const priceScore = maxPrice > 0 ? 1 - c.priceCents / maxPrice : 1;
    const ratingScore = c.ratingAvg / 5;
    const etaScore = maxEta > 0 ? 1 - c.etaMinutes / maxEta : 1;
    const onTimeScore = c.onTimeRate ?? 0.9;

    const rankScore =
      priceScore * 0.35 +
      ratingScore * 0.3 +
      etaScore * 0.2 +
      onTimeScore * 0.15;

    return { ...c, rankScore: Math.round(rankScore * 1000) / 1000 };
  });

  return scored.sort((a, b) => b.rankScore - a.rankScore);
}

export interface BundleCandidate {
  operatorId: string;
  operatorName: string;
  totalPriceCents: number;
  currency: string;
  ratingAvg: number;
  breakdown: { vehicleClass: string; quantity: number; subtotalCents: number }[];
}

/**
 * Group/wedding bundle quoting (Blueprint §3). Same filter-then-rank
 * shape as `findCandidates` (§4.4 design note), just against the
 * fleet-count-aware candidate pool from
 * `findEligibleOperatorsForBundle` instead of a single-vehicle pool.
 */
export function findBundleCandidates(requests: { vehicleClass: string; quantity: number }[], pickupLat: number, pickupLng: number): BundleCandidate[] {
  const eligible = findEligibleOperatorsForBundle(requests, pickupLat, pickupLng);

  const candidates: BundleCandidate[] = eligible.map(({ operator, perClassRule }) => {
    const breakdown = requests.map((req) => {
      const rule = perClassRule[req.vehicleClass];
      // Nominal 12-mile / 25-minute trip per vehicle, same Phase 0
      // placeholder assumption as single-vehicle quoting until real
      // dropoff-based routing is integrated.
      const perVehicle = computeFareCents(rule, 12, 25);
      return { vehicleClass: req.vehicleClass, quantity: req.quantity, subtotalCents: perVehicle * req.quantity };
    });

    return {
      operatorId: operator.id,
      operatorName: operator.displayName,
      totalPriceCents: breakdown.reduce((sum, b) => sum + b.subtotalCents, 0),
      currency: "USD",
      ratingAvg: operator.ratingAvg,
      breakdown,
    };
  });

  return candidates.sort((a, b) => a.totalPriceCents - b.totalPriceCents);
}

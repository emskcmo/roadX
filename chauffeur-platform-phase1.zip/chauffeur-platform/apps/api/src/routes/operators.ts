import { Router } from "express";
import { z } from "zod";
import {
  createOperator,
  listOperators,
  getOperator,
  verifyOperator,
  createVehicle,
  listVehiclesForOperator,
  createServiceArea,
  listServiceAreasForOperator,
  createPricingRule,
  listPricingRulesForOperator,
  createDriver,
  listDriversForOperator,
} from "../repositories/operatorsRepo.js";
import { listTrips } from "../repositories/tripsRepo.js";

export const operatorsRouter = Router();

const createOperatorSchema = z.object({
  legalName: z.string().min(2),
  displayName: z.string().min(2),
  email: z.string().email(),
  phone: z.string().min(7),
  einNumber: z.string().optional(),
});

// POST /operators — start onboarding (Blueprint §2.2). Starts
// unverified; verification is a separate admin action below.
operatorsRouter.post("/", (req, res) => {
  const parsed = createOperatorSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: "invalid_input", details: parsed.error.flatten() });
  }
  const operator = createOperator(parsed.data);
  res.status(201).json(operator);
});

operatorsRouter.get("/", (_req, res) => {
  const operators = listOperators().map((op) => ({
    ...op,
    vehicles: listVehiclesForOperator(op.id),
    serviceAreas: listServiceAreasForOperator(op.id),
  }));
  res.json(operators);
});

operatorsRouter.get("/:id", (req, res) => {
  const operator = getOperator(req.params.id);
  if (!operator) return res.status(404).json({ error: "not_found" });
  res.json({
    ...operator,
    vehicles: listVehiclesForOperator(operator.id),
    serviceAreas: listServiceAreasForOperator(operator.id),
    pricingRules: listPricingRulesForOperator(operator.id),
    drivers: listDriversForOperator(operator.id),
  });
});

// POST /operators/:id/verify — Phase 0 stands in for the full
// document-review pipeline in Blueprint §2.2 with a single toggle.
operatorsRouter.post("/:id/verify", (req, res) => {
  const operator = verifyOperator(req.params.id);
  if (!operator) return res.status(404).json({ error: "not_found" });
  res.json(operator);
});

const vehicleSchema = z.object({
  vehicleClass: z.enum(["sedan", "suv", "sprinter", "stretch", "motor_coach"]),
  make: z.string(),
  model: z.string(),
  year: z.number().int().gte(1990),
  capacity: z.number().int().gte(1),
  amenities: z.array(z.string()).optional(),
});

operatorsRouter.post("/:id/vehicles", (req, res) => {
  const parsed = vehicleSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "invalid_input", details: parsed.error.flatten() });
  const vehicle = createVehicle(req.params.id, parsed.data);
  res.status(201).json(vehicle);
});

const serviceAreaSchema = z.object({
  label: z.string(),
  centerLat: z.number(),
  centerLng: z.number(),
  radiusMi: z.number().positive(),
  airportCodes: z.array(z.string()).optional(),
});

operatorsRouter.post("/:id/service-areas", (req, res) => {
  const parsed = serviceAreaSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "invalid_input", details: parsed.error.flatten() });
  const area = createServiceArea(req.params.id, parsed.data);
  res.status(201).json(area);
});

const pricingRuleSchema = z.object({
  vehicleClass: z.enum(["sedan", "suv", "sprinter", "stretch", "motor_coach"]),
  serviceType: z.enum(["airport", "hourly", "point_to_point", "long_distance"]),
  baseFareCents: z.number().int().nonnegative(),
  perMileCents: z.number().int().nonnegative(),
  perMinuteCents: z.number().int().nonnegative().optional(),
  minimumFareCents: z.number().int().nonnegative(),
});

operatorsRouter.post("/:id/pricing-rules", (req, res) => {
  const parsed = pricingRuleSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "invalid_input", details: parsed.error.flatten() });
  const rule = createPricingRule(req.params.id, parsed.data);
  res.status(201).json(rule);
});

const driverSchema = z.object({
  name: z.string().min(2),
  licenseNumber: z.string().min(2),
  backgroundCheckState: z.enum(["pending", "passed", "failed"]).optional(),
});

operatorsRouter.post("/:id/drivers", (req, res) => {
  const parsed = driverSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "invalid_input", details: parsed.error.flatten() });
  const driver = createDriver(req.params.id, parsed.data);
  res.status(201).json(driver);
});

operatorsRouter.get("/:id/drivers", (req, res) => {
  res.json(listDriversForOperator(req.params.id));
});

// Reservations inbox for a given operator — feeds the Operator
// Dashboard "Reservations" module (Blueprint §8.1).
operatorsRouter.get("/:id/trips", (req, res) => {
  const trips = listTrips({ operatorId: req.params.id });
  res.json(trips);
});

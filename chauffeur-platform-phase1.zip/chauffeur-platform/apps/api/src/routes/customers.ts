import { Router } from "express";
import { z } from "zod";
import { upsertCustomer } from "../repositories/customersRepo.js";

export const customersRouter = Router();

const createCustomerSchema = z.object({
  email: z.string().email(),
  name: z.string().min(1),
  phone: z.string().optional(),
});

// Phase 0 has no real auth yet — this is a stand-in "get or create
// a customer by email" so the booking flow has something to attach
// trips to. Real auth (magic link / SSO for corporate, Blueprint
// §6.10) is a later pass.
customersRouter.post("/", (req, res) => {
  const parsed = createCustomerSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "invalid_input" });

  const customer = upsertCustomer(parsed.data);
  res.status(201).json(customer);
});

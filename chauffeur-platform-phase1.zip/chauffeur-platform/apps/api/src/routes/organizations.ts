import { Router } from "express";
import { z } from "zod";
import {
  createOrganization,
  listOrganizations,
  getOrganization,
  listUnbilledTrips,
  createInvoice,
  listInvoicesForOrganization,
} from "../repositories/organizationsRepo.js";
import { listTrips } from "../repositories/tripsRepo.js";

export const organizationsRouter = Router();

const createOrgSchema = z.object({
  name: z.string().min(2),
  billingEmail: z.string().email(),
});

// POST /organizations — Phase 1 simple corporate account (Blueprint
// §6). Full RBAC/departments/approval-chains are a later pass.
organizationsRouter.post("/", (req, res) => {
  const parsed = createOrgSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "invalid_input", details: parsed.error.flatten() });
  res.status(201).json(createOrganization(parsed.data));
});

organizationsRouter.get("/", (_req, res) => {
  res.json(listOrganizations());
});

organizationsRouter.get("/:id", (req, res) => {
  const org = getOrganization(req.params.id);
  if (!org) return res.status(404).json({ error: "not_found" });
  res.json(org);
});

organizationsRouter.get("/:id/trips", (req, res) => {
  res.json(listTrips({ organizationId: req.params.id }));
});

// GET /organizations/:id/unbilled — the billable pool for the next invoice.
organizationsRouter.get("/:id/unbilled", (req, res) => {
  const trips = listUnbilledTrips(req.params.id);
  const totalCents = trips.reduce((sum: number, t: any) => sum + (t.total_cents ?? 0), 0);
  res.json({ trips, totalCents, currency: "USD" });
});

// POST /organizations/:id/invoices — Phase 1 consolidated invoicing
// (Blueprint §6.6): bundles every unbilled confirmed/completed trip
// into one invoice and marks them billed. Real PDF/CSV export and
// net-30 terms are a later pass.
organizationsRouter.post("/:id/invoices", (req, res) => {
  const trips = listUnbilledTrips(req.params.id);
  if (trips.length === 0) return res.status(400).json({ error: "nothing_to_bill" });
  const totalCents = trips.reduce((sum: number, t: any) => sum + (t.total_cents ?? 0), 0);
  const invoice = createInvoice(req.params.id, trips.map((t: any) => t.id), totalCents, "USD");
  res.status(201).json(invoice);
});

organizationsRouter.get("/:id/invoices", (req, res) => {
  res.json(listInvoicesForOrganization(req.params.id));
});

import { Router } from "express";
import { z } from "zod";
import { findCandidates, findBundleCandidates } from "../services/distributionEngine.js";
import {
  createTripRequest,
  getTrip,
  listTrips,
  setTripStatus,
  confirmTrip,
  assignDriver,
  createQuote,
  listQuotesForTrip,
  getQuote,
} from "../repositories/tripsRepo.js";
import { createMessage, listMessagesForTrip } from "../repositories/messagesRepo.js";

export const tripsRouter = Router();

const quoteRequestSchema = z.object({
  customerId: z.string(),
  serviceType: z.enum(["airport", "hourly", "point_to_point", "long_distance", "wedding", "group"]),
  vehicleClass: z.enum(["sedan", "suv", "sprinter", "stretch", "motor_coach"]),
  passengerCount: z.number().int().gte(1),
  luggageCount: z.number().int().gte(0).optional(),
  flightNumber: z.string().optional(),
  organizationId: z.string().optional(),
  pickup: z.object({
    label: z.string(),
    lat: z.number(),
    lng: z.number(),
  }),
  dropoff: z
    .object({
      label: z.string(),
      lat: z.number(),
      lng: z.number(),
    })
    .optional(),
  scheduledAt: z.string(),
});

// POST /trips/quote-request — step 1-2 of the booking flow
// (Blueprint §3.1): create the trip in `requested` state, run the
// Distribution Engine, persist the resulting Quotes, return them.
tripsRouter.post("/quote-request", (req, res) => {
  const parsed = quoteRequestSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "invalid_input", details: parsed.error.flatten() });
  const input = parsed.data;

  const trip = createTripRequest({
    customerId: input.customerId,
    serviceType: input.serviceType,
    passengerCount: input.passengerCount,
    luggageCount: input.luggageCount,
    flightNumber: input.flightNumber,
    organizationId: input.organizationId,
    leg: {
      pickupLabel: input.pickup.label,
      pickupLat: input.pickup.lat,
      pickupLng: input.pickup.lng,
      dropoffLabel: input.dropoff?.label,
      dropoffLat: input.dropoff?.lat,
      dropoffLng: input.dropoff?.lng,
      scheduledAt: input.scheduledAt,
      vehicleClass: input.vehicleClass,
    },
  });

  const candidates = findCandidates({
    pickupLat: input.pickup.lat,
    pickupLng: input.pickup.lng,
    vehicleClass: input.vehicleClass,
    serviceType: input.serviceType,
  });

  const expiresAt = new Date(Date.now() + 10 * 60 * 1000).toISOString();

  const quotes = candidates.map((c) =>
    createQuote({
      tripId: trip.id,
      operatorId: c.operatorId,
      priceCents: c.priceCents,
      currency: c.currency,
      etaMinutes: c.etaMinutes,
      vehicleClass: c.vehicleClass,
      rankScore: c.rankScore,
      expiresAt,
    })
  );

  setTripStatus(trip.id, candidates.length ? "quoted" : "requested");

  res.status(201).json({
    tripId: trip.id,
    quotes: quotes.map((q, i) => ({
      ...q,
      operatorName: candidates[i].operatorName,
      ratingAvg: candidates[i].ratingAvg,
    })),
  });
});

const groupQuoteRequestSchema = z.object({
  customerId: z.string(),
  serviceType: z.enum(["wedding", "group"]),
  passengerCount: z.number().int().gte(1),
  pickup: z.object({ label: z.string(), lat: z.number(), lng: z.number() }),
  scheduledAt: z.string(),
  vehicles: z.array(z.object({ vehicleClass: z.enum(["sedan", "suv", "sprinter", "stretch", "motor_coach"]), quantity: z.number().int().gte(1) })).min(1),
});

// POST /trips/group-quote-request — the wedding/group journey
// (Blueprint §3): one trip asking for several vehicles at once,
// bundled into a single quote per capable operator.
tripsRouter.post("/group-quote-request", (req, res) => {
  const parsed = groupQuoteRequestSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "invalid_input", details: parsed.error.flatten() });
  const input = parsed.data;

  const primaryClass = input.vehicles[0].vehicleClass;
  const trip = createTripRequest({
    customerId: input.customerId,
    serviceType: input.serviceType,
    passengerCount: input.passengerCount,
    leg: {
      pickupLabel: input.pickup.label,
      pickupLat: input.pickup.lat,
      pickupLng: input.pickup.lng,
      scheduledAt: input.scheduledAt,
      vehicleClass: primaryClass,
    },
    vehicleRequests: input.vehicles,
  });

  const bundles = findBundleCandidates(input.vehicles, input.pickup.lat, input.pickup.lng);

  const expiresAt = new Date(Date.now() + 10 * 60 * 1000).toISOString();
  const quotes = bundles.map((b) =>
    createQuote({
      tripId: trip.id,
      operatorId: b.operatorId,
      priceCents: b.totalPriceCents,
      currency: b.currency,
      etaMinutes: 20,
      vehicleClass: "bundle",
      rankScore: 0,
      expiresAt,
    })
  );

  setTripStatus(trip.id, bundles.length ? "quoted" : "requested");

  res.status(201).json({
    tripId: trip.id,
    quotes: quotes.map((q, i) => ({ ...q, operatorName: bundles[i].operatorName, ratingAvg: bundles[i].ratingAvg, breakdown: bundles[i].breakdown })),
  });
});

const confirmSchema = z.object({ quoteId: z.string() });

// POST /trips/:id/confirm — step 5: customer picks a quote, trip
// confirms with that operator (Blueprint §3.1, step 5-6).
tripsRouter.post("/:id/confirm", (req, res) => {
  const parsed = confirmSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "invalid_input" });

  const quote = getQuote(parsed.data.quoteId);
  if (!quote || quote.tripId !== req.params.id) return res.status(404).json({ error: "quote_not_found" });
  if (new Date(quote.expiresAt) < new Date()) return res.status(410).json({ error: "quote_expired" });

  const trip = confirmTrip(req.params.id, quote.operatorId, quote.priceCents, quote.currency);
  res.json(trip);
});

const assignDriverSchema = z.object({ driverId: z.string() });

// POST /trips/:id/assign-driver — driver scheduling (Blueprint §8.1):
// the operator assigns one of their own drivers to a confirmed trip.
tripsRouter.post("/:id/assign-driver", (req, res) => {
  const parsed = assignDriverSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "invalid_input" });
  const trip = assignDriver(req.params.id, parsed.data.driverId);
  res.json(trip);
});

tripsRouter.get("/:id", (req, res) => {
  const trip = getTrip(req.params.id);
  if (!trip) return res.status(404).json({ error: "not_found" });
  res.json({ ...trip, quotes: listQuotesForTrip(trip.id) });
});

tripsRouter.get("/", (req, res) => {
  const customerId = req.query.customerId as string | undefined;
  res.json(listTrips({ customerId }));
});

const messageSchema = z.object({
  senderType: z.enum(["customer", "operator"]),
  senderName: z.string(),
  body: z.string().min(1),
});

// In-app chat (Blueprint §3.1). Phase 1: simple polled thread, no
// masked-number voice or read receipts yet.
tripsRouter.post("/:id/messages", (req, res) => {
  const parsed = messageSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "invalid_input" });
  const message = createMessage({ tripId: req.params.id, ...parsed.data });
  res.status(201).json(message);
});

tripsRouter.get("/:id/messages", (req, res) => {
  res.json(listMessagesForTrip(req.params.id));
});

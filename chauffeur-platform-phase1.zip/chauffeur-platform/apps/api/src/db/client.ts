import { DatabaseSync } from "node:sqlite";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import path from "node:path";

/**
 * Phase 0 runtime data layer. Uses Node's built-in `node:sqlite`
 * (stable-ish/experimental as of Node 22) so this scaffold runs with
 * zero native builds and zero external downloads — see
 * docs/data-model.prisma for the canonical Postgres/Prisma schema
 * this mirrors, and the note at the top of that file for how to
 * migrate off this once you're deploying for real.
 */

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dbFile = process.env.DATABASE_FILE ?? "./dev.db";

export const db = new DatabaseSync(dbFile);
db.exec("PRAGMA foreign_keys = ON;");

const schema = readFileSync(path.join(__dirname, "schema.sql"), "utf-8");
db.exec(schema);

export function newId(prefix: string): string {
  return `${prefix}_${crypto.randomUUID().replace(/-/g, "")}`;
}

export function nowIso(): string {
  return new Date().toISOString();
}

/** Parse a nullable JSON text column back into a JS value. */
export function parseJson<T>(value: unknown): T | null {
  if (typeof value !== "string") return null;
  try {
    return JSON.parse(value) as T;
  } catch {
    return null;
  }
}

-- Mirrors docs/data-model.prisma. Kept in sync by hand for Phase 0 —
-- once this moves to Postgres/Prisma, this file goes away and
-- `prisma migrate` takes over.

CREATE TABLE IF NOT EXISTS customers (
  id TEXT PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  phone TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS operators (
  id TEXT PRIMARY KEY,
  legal_name TEXT NOT NULL,
  display_name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  phone TEXT NOT NULL,
  verified INTEGER NOT NULL DEFAULT 0,
  verified_at TEXT,
  business_license_url TEXT,
  insurance_cert_url TEXT,
  ein_number TEXT,
  rating_avg REAL NOT NULL DEFAULT 0,
  rating_count INTEGER NOT NULL DEFAULT 0,
  on_time_rate REAL,
  acceptance_rate REAL,
  cancel_rate REAL,
  tier TEXT NOT NULL DEFAULT 'standard',
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS vehicles (
  id TEXT PRIMARY KEY,
  operator_id TEXT NOT NULL REFERENCES operators(id) ON DELETE CASCADE,
  vehicle_class TEXT NOT NULL,
  make TEXT NOT NULL,
  model TEXT NOT NULL,
  year INTEGER NOT NULL,
  capacity INTEGER NOT NULL,
  photo_urls TEXT,
  amenities TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS drivers (
  id TEXT PRIMARY KEY,
  operator_id TEXT NOT NULL REFERENCES operators(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  license_number TEXT NOT NULL,
  background_check_state TEXT NOT NULL DEFAULT 'pending',
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS service_areas (
  id TEXT PRIMARY KEY,
  operator_id TEXT NOT NULL REFERENCES operators(id) ON DELETE CASCADE,
  label TEXT NOT NULL,
  center_lat REAL NOT NULL,
  center_lng REAL NOT NULL,
  radius_mi REAL NOT NULL,
  airport_codes TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS pricing_rules (
  id TEXT PRIMARY KEY,
  operator_id TEXT NOT NULL REFERENCES operators(id) ON DELETE CASCADE,
  vehicle_class TEXT NOT NULL,
  service_type TEXT NOT NULL,
  base_fare_cents INTEGER NOT NULL,
  per_mile_cents INTEGER NOT NULL,
  per_minute_cents INTEGER NOT NULL DEFAULT 0,
  minimum_fare_cents INTEGER NOT NULL,
  currency TEXT NOT NULL DEFAULT 'USD',
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS trips (
  id TEXT PRIMARY KEY,
  customer_id TEXT NOT NULL REFERENCES customers(id),
  service_type TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'requested',
  passenger_count INTEGER NOT NULL,
  luggage_count INTEGER NOT NULL DEFAULT 0,
  flight_number TEXT,
  operator_id TEXT REFERENCES operators(id),
  vehicle_id TEXT,
  driver_id TEXT,
  total_cents INTEGER,
  currency TEXT NOT NULL DEFAULT 'USD',
  organization_id TEXT,
  cost_center TEXT,
  approval_status TEXT,
  network_status TEXT,
  invoiced INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS legs (
  id TEXT PRIMARY KEY,
  trip_id TEXT NOT NULL REFERENCES trips(id) ON DELETE CASCADE,
  sequence INTEGER NOT NULL,
  pickup_label TEXT NOT NULL,
  pickup_lat REAL NOT NULL,
  pickup_lng REAL NOT NULL,
  dropoff_label TEXT,
  dropoff_lat REAL,
  dropoff_lng REAL,
  scheduled_at TEXT NOT NULL,
  duration_min INTEGER,
  vehicle_class TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS quotes (
  id TEXT PRIMARY KEY,
  trip_id TEXT NOT NULL REFERENCES trips(id) ON DELETE CASCADE,
  operator_id TEXT NOT NULL,
  price_cents INTEGER NOT NULL,
  currency TEXT NOT NULL DEFAULT 'USD',
  eta_minutes INTEGER NOT NULL,
  vehicle_class TEXT NOT NULL,
  rank_score REAL NOT NULL,
  expires_at TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS ratings (
  id TEXT PRIMARY KEY,
  trip_id TEXT NOT NULL REFERENCES trips(id),
  customer_id TEXT NOT NULL REFERENCES customers(id),
  operator_id TEXT NOT NULL REFERENCES operators(id),
  stars INTEGER NOT NULL,
  comment TEXT,
  created_at TEXT NOT NULL
);

-- ── Phase 1 additions ──────────────────────────────────────────────

-- Simple corporate account (Blueprint §6). Full RBAC/departments/
-- approval-chains are a later pass — Phase 1 just needs an entity
-- to bill against and tag trips with.
CREATE TABLE IF NOT EXISTS organizations (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  billing_email TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS invoices (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id),
  period_start TEXT NOT NULL,
  period_end TEXT NOT NULL,
  total_cents INTEGER NOT NULL,
  currency TEXT NOT NULL DEFAULT 'USD',
  status TEXT NOT NULL DEFAULT 'issued',
  created_at TEXT NOT NULL
);

-- Which vehicles (class + quantity) a group/wedding booking asked
-- for. A single Trip can request e.g. 2 sedans + 1 SUV; the
-- Distribution Engine bundles a quote from one operator who can
-- supply the whole order (Blueprint §3, wedding/group journey).
CREATE TABLE IF NOT EXISTS trip_vehicle_requests (
  id TEXT PRIMARY KEY,
  trip_id TEXT NOT NULL REFERENCES trips(id) ON DELETE CASCADE,
  vehicle_class TEXT NOT NULL,
  quantity INTEGER NOT NULL
);

-- Trip-scoped chat between customer and operator (Blueprint §3.1
-- "in-app chat"). Phase 1 keeps this simple: no read receipts,
-- no masked-number voice — just a message thread per trip.
CREATE TABLE IF NOT EXISTS messages (
  id TEXT PRIMARY KEY,
  trip_id TEXT NOT NULL REFERENCES trips(id) ON DELETE CASCADE,
  sender_type TEXT NOT NULL,
  sender_name TEXT NOT NULL,
  body TEXT NOT NULL,
  created_at TEXT NOT NULL
);

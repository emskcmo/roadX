import { db } from "./client.js";
import { createOperator, verifyOperator, createServiceArea, createVehicle, createPricingRule, createDriver } from "../repositories/operatorsRepo.js";
import { upsertCustomer } from "../repositories/customersRepo.js";
import { createOrganization } from "../repositories/organizationsRepo.js";

// Kansas City metro coordinates — used as the seed market so the
// demo has real quote results out of the box.
const KC = { lat: 39.0997, lng: -94.5786 };

function reset() {
  db.exec(`
    DELETE FROM messages;
    DELETE FROM invoices;
    DELETE FROM organizations;
    DELETE FROM trip_vehicle_requests;
    DELETE FROM quotes;
    DELETE FROM ratings;
    DELETE FROM legs;
    DELETE FROM trips;
    DELETE FROM pricing_rules;
    DELETE FROM service_areas;
    DELETE FROM vehicles;
    DELETE FROM drivers;
    DELETE FROM operators;
    DELETE FROM customers;
  `);
}

function main() {
  console.log("Seeding demo data...");
  reset();

  const operatorsData = [
    {
      legalName: "Heartland Executive Transport LLC",
      displayName: "Heartland Executive",
      email: "ops@heartlandexec.example",
      phone: "816-555-0101",
      base: 1200,
      perMile: 280,
      perMinute: 35,
      minFare: 4500,
      sedanCount: 4,
      suvCount: 3,
    },
    {
      legalName: "Midwest Black Car Co.",
      displayName: "Midwest Black Car",
      email: "dispatch@midwestblackcar.example",
      phone: "816-555-0142",
      base: 900,
      perMile: 240,
      perMinute: 30,
      minFare: 3800,
      sedanCount: 2,
      suvCount: 2,
    },
    {
      legalName: "River City Chauffeurs Inc.",
      displayName: "River City Chauffeurs",
      email: "hello@rivercitychauffeurs.example",
      phone: "913-555-0177",
      base: 700,
      perMile: 200,
      perMinute: 20,
      minFare: 3200,
      sedanCount: 1,
      suvCount: 1,
    },
  ];

  for (const o of operatorsData) {
    const operator = createOperator({
      legalName: o.legalName,
      displayName: o.displayName,
      email: o.email,
      phone: o.phone,
    });
    verifyOperator(operator.id);

    createServiceArea(operator.id, {
      label: "Kansas City Metro",
      centerLat: KC.lat,
      centerLng: KC.lng,
      radiusMi: 35,
      airportCodes: ["MCI"],
    });

    for (const vehicleClass of ["sedan", "suv"] as const) {
      const count = vehicleClass === "sedan" ? o.sedanCount : o.suvCount;
      for (let i = 0; i < count; i++) {
        createVehicle(operator.id, {
          vehicleClass,
          make: vehicleClass === "sedan" ? "Cadillac" : "Chevrolet",
          model: vehicleClass === "sedan" ? "CT5" : "Suburban",
          year: 2024,
          capacity: vehicleClass === "sedan" ? 3 : 6,
          amenities: ["bottled water", "wifi", "phone chargers"],
        });
      }

      for (const serviceType of ["airport", "hourly", "point_to_point"] as const) {
        createPricingRule(operator.id, {
          vehicleClass,
          serviceType,
          baseFareCents: o.base + (vehicleClass === "suv" ? 400 : 0),
          perMileCents: o.perMile,
          perMinuteCents: o.perMinute,
          minimumFareCents: o.minFare + (vehicleClass === "suv" ? 800 : 0),
        });
      }
    }

    // Driver roster (Blueprint §8.1 driver scheduling) — a few
    // per operator so the dashboard's assignment flow has options.
    for (let i = 0; i < 3; i++) {
      createDriver(operator.id, {
        name: `Driver ${i + 1} — ${o.displayName}`,
        licenseNumber: `MO-CH-${Math.floor(Math.random() * 900000 + 100000)}`,
        backgroundCheckState: "passed",
      });
    }
  }

  // Bump ratings/on-time rates directly (not exposed via API yet —
  // these are normally rolling-computed, Blueprint §8).
  const ratingSeed = [
    { email: "ops@heartlandexec.example", ratingAvg: 4.9, ratingCount: 412, onTime: 0.98, tier: "elite" },
    { email: "dispatch@midwestblackcar.example", ratingAvg: 4.7, ratingCount: 208, onTime: 0.94, tier: "preferred" },
    { email: "hello@rivercitychauffeurs.example", ratingAvg: 4.4, ratingCount: 63, onTime: 0.88, tier: "standard" },
  ];
  for (const r of ratingSeed) {
    db.prepare("UPDATE operators SET rating_avg = ?, rating_count = ?, on_time_rate = ?, tier = ? WHERE email = ?").run(
      r.ratingAvg,
      r.ratingCount,
      r.onTime,
      r.tier,
      r.email
    );
  }

  const demoCustomer = upsertCustomer({ email: "demo.customer@example.com", name: "Jordan Ellis", phone: "816-555-0199" });

  // Demo corporate account (Blueprint §6) so the corporate booking
  // flow has something to attach trips/invoices to out of the box.
  const demoOrg = createOrganization({ name: "Ellison & Marsh LLP", billingEmail: "travel@ellisonmarsh.example" });

  console.log(`Seeded ${operatorsData.length} operators, demo customer ${demoCustomer.email}, demo org ${demoOrg.name} (id: ${demoOrg.id})`);
}

main();

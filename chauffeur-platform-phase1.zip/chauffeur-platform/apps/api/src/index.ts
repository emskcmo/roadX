import express from "express";
import cors from "cors";
import { operatorsRouter } from "./routes/operators.js";
import { tripsRouter } from "./routes/trips.js";
import { customersRouter } from "./routes/customers.js";
import { organizationsRouter } from "./routes/organizations.js";

const app = express();
app.use(cors());
app.use(express.json());

app.get("/health", (_req, res) => res.json({ status: "ok", phase: "1 - corporate, group booking, drivers, chat" }));

app.use("/operators", operatorsRouter);
app.use("/trips", tripsRouter);
app.use("/customers", customersRouter);
app.use("/organizations", organizationsRouter);

const port = Number(process.env.PORT ?? 4000);
app.listen(port, () => {
  console.log(`API listening on http://localhost:${port}`);
});

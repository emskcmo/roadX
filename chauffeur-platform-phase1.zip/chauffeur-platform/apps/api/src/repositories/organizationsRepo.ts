import { db, newId, nowIso } from "../db/client.js";

export interface Organization {
  id: string;
  name: string;
  billingEmail: string;
  createdAt: string;
}

export interface Invoice {
  id: string;
  organizationId: string;
  periodStart: string;
  periodEnd: string;
  totalCents: number;
  currency: string;
  status: string;
  createdAt: string;
}

function mapOrg(row: any): Organization {
  return { id: row.id, name: row.name, billingEmail: row.billing_email, createdAt: row.created_at };
}

function mapInvoice(row: any): Invoice {
  return {
    id: row.id,
    organizationId: row.organization_id,
    periodStart: row.period_start,
    periodEnd: row.period_end,
    totalCents: row.total_cents,
    currency: row.currency,
    status: row.status,
    createdAt: row.created_at,
  };
}

export function createOrganization(input: { name: string; billingEmail: string }): Organization {
  const id = newId("org");
  const createdAt = nowIso();
  db.prepare("INSERT INTO organizations (id, name, billing_email, created_at) VALUES (?, ?, ?, ?)").run(
    id,
    input.name,
    input.billingEmail,
    createdAt
  );
  return { id, ...input, createdAt };
}

export function listOrganizations(): Organization[] {
  return (db.prepare("SELECT * FROM organizations ORDER BY created_at DESC").all() as any[]).map(mapOrg);
}

export function getOrganization(id: string): Organization | null {
  const row = db.prepare("SELECT * FROM organizations WHERE id = ?").get(id) as any;
  return row ? mapOrg(row) : null;
}

/** Confirmed, not-yet-invoiced trips for an org — the billable pool. */
export function listUnbilledTrips(organizationId: string) {
  return db
    .prepare(
      `SELECT * FROM trips WHERE organization_id = ? AND invoiced = 0 AND status IN ('confirmed', 'completed') ORDER BY created_at`
    )
    .all(organizationId) as any[];
}

export function createInvoice(organizationId: string, tripIds: string[], totalCents: number, currency: string): Invoice {
  const id = newId("inv");
  const createdAt = nowIso();

  db.prepare(
    `INSERT INTO invoices (id, organization_id, period_start, period_end, total_cents, currency, status, created_at)
     VALUES (?, ?, ?, ?, ?, ?, 'issued', ?)`
  ).run(id, organizationId, createdAt, createdAt, totalCents, currency, createdAt);

  const markBilled = db.prepare("UPDATE trips SET invoiced = 1 WHERE id = ?");
  for (const tripId of tripIds) markBilled.run(tripId);

  return { id, organizationId, periodStart: createdAt, periodEnd: createdAt, totalCents, currency, status: "issued", createdAt };
}

export function listInvoicesForOrganization(organizationId: string): Invoice[] {
  return (
    db.prepare("SELECT * FROM invoices WHERE organization_id = ? ORDER BY created_at DESC").all(organizationId) as any[]
  ).map(mapInvoice);
}

import { db, newId, nowIso, parseJson } from "../db/client.js";
import { distanceMiles } from "../lib/geo.js";

export interface Operator {
  id: string;
  legalName: string;
  displayName: string;
  email: string;
  phone: string;
  verified: boolean;
  verifiedAt: string | null;
  ratingAvg: number;
  ratingCount: number;
  onTimeRate: number | null;
  acceptanceRate: number | null;
  cancelRate: number | null;
  tier: string;
  createdAt: string;
}

export interface Vehicle {
  id: string;
  operatorId: string;
  vehicleClass: string;
  make: string;
  model: string;
  year: number;
  capacity: number;
  amenities: string[] | null;
  active: boolean;
}

export interface ServiceArea {
  id: string;
  operatorId: string;
  label: string;
  centerLat: number;
  centerLng: number;
  radiusMi: number;
  airportCodes: string[] | null;
}

export interface PricingRule {
  id: string;
  operatorId: string;
  vehicleClass: string;
  serviceType: string;
  baseFareCents: number;
  perMileCents: number;
  perMinuteCents: number;
  minimumFareCents: number;
  currency: string;
}

export interface Driver {
  id: string;
  operatorId: string;
  name: string;
  licenseNumber: string;
  backgroundCheckState: string;
  active: boolean;
}

function mapOperator(row: any): Operator {
  return {
    id: row.id,
    legalName: row.legal_name,
    displayName: row.display_name,
    email: row.email,
    phone: row.phone,
    verified: !!row.verified,
    verifiedAt: row.verified_at,
    ratingAvg: row.rating_avg,
    ratingCount: row.rating_count,
    onTimeRate: row.on_time_rate,
    acceptanceRate: row.acceptance_rate,
    cancelRate: row.cancel_rate,
    tier: row.tier,
    createdAt: row.created_at,
  };
}

function mapVehicle(row: any): Vehicle {
  return {
    id: row.id,
    operatorId: row.operator_id,
    vehicleClass: row.vehicle_class,
    make: row.make,
    model: row.model,
    year: row.year,
    capacity: row.capacity,
    amenities: parseJson<string[]>(row.amenities),
    active: !!row.active,
  };
}

function mapServiceArea(row: any): ServiceArea {
  return {
    id: row.id,
    operatorId: row.operator_id,
    label: row.label,
    centerLat: row.center_lat,
    centerLng: row.center_lng,
    radiusMi: row.radius_mi,
    airportCodes: parseJson<string[]>(row.airport_codes),
  };
}

function mapPricingRule(row: any): PricingRule {
  return {
    id: row.id,
    operatorId: row.operator_id,
    vehicleClass: row.vehicle_class,
    serviceType: row.service_type,
    baseFareCents: row.base_fare_cents,
    perMileCents: row.per_mile_cents,
    perMinuteCents: row.per_minute_cents,
    minimumFareCents: row.minimum_fare_cents,
    currency: row.currency,
  };
}

function mapDriver(row: any): Driver {
  return {
    id: row.id,
    operatorId: row.operator_id,
    name: row.name,
    licenseNumber: row.license_number,
    backgroundCheckState: row.background_check_state,
    active: !!row.active,
  };
}

export function createOperator(input: {
  legalName: string;
  displayName: string;
  email: string;
  phone: string;
  einNumber?: string;
}): Operator {
  const id = newId("op");
  const createdAt = nowIso();
  db.prepare(
    `INSERT INTO operators (id, legal_name, display_name, email, phone, ein_number, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  ).run(id, input.legalName, input.displayName, input.email, input.phone, input.einNumber ?? null, createdAt);
  return getOperator(id)!;
}

export function listOperators(): Operator[] {
  const rows = db.prepare("SELECT * FROM operators ORDER BY created_at DESC").all() as any[];
  return rows.map(mapOperator);
}

export function getOperator(id: string): Operator | null {
  const row = db.prepare("SELECT * FROM operators WHERE id = ?").get(id) as any;
  return row ? mapOperator(row) : null;
}

export function verifyOperator(id: string): Operator | null {
  db.prepare("UPDATE operators SET verified = 1, verified_at = ? WHERE id = ?").run(nowIso(), id);
  return getOperator(id);
}

export function listVehiclesForOperator(operatorId: string): Vehicle[] {
  const rows = db.prepare("SELECT * FROM vehicles WHERE operator_id = ?").all(operatorId) as any[];
  return rows.map(mapVehicle);
}

export function createVehicle(
  operatorId: string,
  input: Omit<Vehicle, "id" | "operatorId" | "active" | "amenities"> & { amenities?: string[] }
): Vehicle {
  const id = newId("veh");
  db.prepare(
    `INSERT INTO vehicles (id, operator_id, vehicle_class, make, model, year, capacity, amenities, active, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?)`
  ).run(id, operatorId, input.vehicleClass, input.make, input.model, input.year, input.capacity, JSON.stringify(input.amenities ?? []), nowIso());
  return { id, operatorId, active: true, ...input, amenities: input.amenities ?? null };
}

export function listServiceAreasForOperator(operatorId: string): ServiceArea[] {
  const rows = db.prepare("SELECT * FROM service_areas WHERE operator_id = ?").all(operatorId) as any[];
  return rows.map(mapServiceArea);
}

export function createServiceArea(
  operatorId: string,
  input: Omit<ServiceArea, "id" | "operatorId" | "airportCodes"> & { airportCodes?: string[] }
): ServiceArea {
  const id = newId("area");
  db.prepare(
    `INSERT INTO service_areas (id, operator_id, label, center_lat, center_lng, radius_mi, airport_codes, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(id, operatorId, input.label, input.centerLat, input.centerLng, input.radiusMi, JSON.stringify(input.airportCodes ?? []), nowIso());
  return { id, operatorId, ...input, airportCodes: input.airportCodes ?? null };
}

export function listPricingRulesForOperator(operatorId: string): PricingRule[] {
  const rows = db.prepare("SELECT * FROM pricing_rules WHERE operator_id = ?").all(operatorId) as any[];
  return rows.map(mapPricingRule);
}

export function createPricingRule(
  operatorId: string,
  input: Omit<PricingRule, "id" | "operatorId" | "currency" | "perMinuteCents"> & { perMinuteCents?: number }
): PricingRule {
  const id = newId("rule");
  db.prepare(
    `INSERT INTO pricing_rules (id, operator_id, vehicle_class, service_type, base_fare_cents, per_mile_cents, per_minute_cents, minimum_fare_cents, currency, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'USD', ?)`
  ).run(
    id,
    operatorId,
    input.vehicleClass,
    input.serviceType,
    input.baseFareCents,
    input.perMileCents,
    input.perMinuteCents ?? 0,
    input.minimumFareCents,
    nowIso()
  );
  return { id, operatorId, currency: "USD", ...input, perMinuteCents: input.perMinuteCents ?? 0 };
}

export function createDriver(operatorId: string, input: { name: string; licenseNumber: string; backgroundCheckState?: string }): Driver {
  const id = newId("drv");
  db.prepare(
    `INSERT INTO drivers (id, operator_id, name, license_number, background_check_state, active, created_at)
     VALUES (?, ?, ?, ?, ?, 1, ?)`
  ).run(id, operatorId, input.name, input.licenseNumber, input.backgroundCheckState ?? "pending", nowIso());
  return {
    id,
    operatorId,
    name: input.name,
    licenseNumber: input.licenseNumber,
    backgroundCheckState: input.backgroundCheckState ?? "pending",
    active: true,
  };
}

export function listDriversForOperator(operatorId: string): Driver[] {
  const rows = db.prepare("SELECT * FROM drivers WHERE operator_id = ? AND active = 1").all(operatorId) as any[];
  return rows.map(mapDriver);
}

export function getDriver(id: string): Driver | null {
  const row = db.prepare("SELECT * FROM drivers WHERE id = ?").get(id) as any;
  return row ? mapDriver(row) : null;
}

/** All verified operators with an active vehicle of the given class, plus their service areas and a matching pricing rule. */
export function findEligibleOperators(vehicleClass: string, serviceType: string) {
  const operators = db.prepare("SELECT * FROM operators WHERE verified = 1").all() as any[];

  return operators
    .map((opRow) => {
      const operator = mapOperator(opRow);
      const vehicle = db
        .prepare("SELECT * FROM vehicles WHERE operator_id = ? AND vehicle_class = ? AND active = 1 LIMIT 1")
        .get(operator.id, vehicleClass) as any;
      const areas = db.prepare("SELECT * FROM service_areas WHERE operator_id = ?").all(operator.id).map(mapServiceArea);
      const rule = db
        .prepare("SELECT * FROM pricing_rules WHERE operator_id = ? AND vehicle_class = ? AND service_type = ? LIMIT 1")
        .get(operator.id, vehicleClass, serviceType) as any;

      if (!vehicle || areas.length === 0 || !rule) return null;
      return { operator, vehicle: mapVehicle(vehicle), serviceAreas: areas, pricingRule: mapPricingRule(rule) };
    })
    .filter((x): x is NonNullable<typeof x> => x !== null);
}

/**
 * Fleet-count-aware matching for group/wedding bookings (Blueprint
 * §3): finds verified operators whose OWNED VEHICLE COUNT per class
 * meets or exceeds every item in the requested bundle, within a
 * covering service area. Unlike single-vehicle matching, this checks
 * quantity, not just existence, since a wedding asking for "3 sedans"
 * needs one operator who can actually field three at once.
 */
export function findEligibleOperatorsForBundle(
  requests: { vehicleClass: string; quantity: number }[],
  pickupLat: number,
  pickupLng: number
) {
  const operators = db.prepare("SELECT * FROM operators WHERE verified = 1").all() as any[];
  const results: { operator: Operator; serviceAreas: ServiceArea[]; perClassRule: Record<string, PricingRule> }[] = [];

  for (const opRow of operators) {
    const operator = mapOperator(opRow);
    const areas = (db.prepare("SELECT * FROM service_areas WHERE operator_id = ?").all(operator.id) as any[]).map(mapServiceArea);
    const covering = areas.some((a) => distanceMiles(a.centerLat, a.centerLng, pickupLat, pickupLng) <= a.radiusMi);
    if (!covering) continue;

    let meetsAll = true;
    const perClassRule: Record<string, PricingRule> = {};

    for (const req of requests) {
      const countRow = db
        .prepare("SELECT COUNT(*) as c FROM vehicles WHERE operator_id = ? AND vehicle_class = ? AND active = 1")
        .get(operator.id, req.vehicleClass) as any;
      if (countRow.c < req.quantity) {
        meetsAll = false;
        break;
      }
      const rule = db
        .prepare(
          "SELECT * FROM pricing_rules WHERE operator_id = ? AND vehicle_class = ? AND service_type IN ('group','wedding','hourly','point_to_point') LIMIT 1"
        )
        .get(operator.id, req.vehicleClass) as any;
      if (!rule) {
        meetsAll = false;
        break;
      }
      perClassRule[req.vehicleClass] = mapPricingRule(rule);
    }

    if (meetsAll) results.push({ operator, serviceAreas: areas, perClassRule });
  }

  return results;
}

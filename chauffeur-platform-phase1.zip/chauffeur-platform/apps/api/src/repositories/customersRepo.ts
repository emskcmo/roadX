import { db, newId, nowIso } from "../db/client.js";

export interface Customer {
  id: string;
  email: string;
  name: string;
  phone: string | null;
  createdAt: string;
}

function mapRow(row: any): Customer {
  return { id: row.id, email: row.email, name: row.name, phone: row.phone, createdAt: row.created_at };
}

export function upsertCustomer(input: { email: string; name: string; phone?: string }): Customer {
  const existing = db.prepare("SELECT * FROM customers WHERE email = ?").get(input.email) as any;
  if (existing) {
    db.prepare("UPDATE customers SET name = ?, phone = ? WHERE id = ?").run(input.name, input.phone ?? null, existing.id);
    return mapRow({ ...existing, name: input.name, phone: input.phone ?? null });
  }
  const id = newId("cus");
  const createdAt = nowIso();
  db.prepare("INSERT INTO customers (id, email, name, phone, created_at) VALUES (?, ?, ?, ?, ?)").run(
    id,
    input.email,
    input.name,
    input.phone ?? null,
    createdAt
  );
  return { id, email: input.email, name: input.name, phone: input.phone ?? null, createdAt };
}

export function getCustomer(id: string): Customer | null {
  const row = db.prepare("SELECT * FROM customers WHERE id = ?").get(id) as any;
  return row ? mapRow(row) : null;
}

import { db, newId, nowIso } from "../db/client.js";

export interface Leg {
  id: string;
  tripId: string;
  sequence: number;
  pickupLabel: string;
  pickupLat: number;
  pickupLng: number;
  dropoffLabel: string | null;
  dropoffLat: number | null;
  dropoffLng: number | null;
  scheduledAt: string;
  vehicleClass: string;
}

export interface VehicleRequest {
  id: string;
  vehicleClass: string;
  quantity: number;
}

export interface Trip {
  id: string;
  customerId: string;
  serviceType: string;
  status: string;
  passengerCount: number;
  luggageCount: number;
  flightNumber: string | null;
  operatorId: string | null;
  driverId: string | null;
  organizationId: string | null;
  totalCents: number | null;
  currency: string;
  createdAt: string;
  updatedAt: string;
  legs: Leg[];
  vehicleRequests: VehicleRequest[];
}

export interface Quote {
  id: string;
  tripId: string;
  operatorId: string;
  priceCents: number;
  currency: string;
  etaMinutes: number;
  vehicleClass: string;
  rankScore: number;
  expiresAt: string;
}

function mapLeg(row: any): Leg {
  return {
    id: row.id,
    tripId: row.trip_id,
    sequence: row.sequence,
    pickupLabel: row.pickup_label,
    pickupLat: row.pickup_lat,
    pickupLng: row.pickup_lng,
    dropoffLabel: row.dropoff_label,
    dropoffLat: row.dropoff_lat,
    dropoffLng: row.dropoff_lng,
    scheduledAt: row.scheduled_at,
    vehicleClass: row.vehicle_class,
  };
}

function mapTrip(row: any): Trip {
  const legs = (db.prepare("SELECT * FROM legs WHERE trip_id = ? ORDER BY sequence").all(row.id) as any[]).map(mapLeg);
  const vehicleRequests = (db.prepare("SELECT * FROM trip_vehicle_requests WHERE trip_id = ?").all(row.id) as any[]).map((r) => ({
    id: r.id,
    vehicleClass: r.vehicle_class,
    quantity: r.quantity,
  }));
  return {
    id: row.id,
    customerId: row.customer_id,
    serviceType: row.service_type,
    status: row.status,
    passengerCount: row.passenger_count,
    luggageCount: row.luggage_count,
    flightNumber: row.flight_number,
    operatorId: row.operator_id,
    driverId: row.driver_id,
    organizationId: row.organization_id,
    totalCents: row.total_cents,
    currency: row.currency,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    legs,
    vehicleRequests,
  };
}

function mapQuote(row: any): Quote {
  return {
    id: row.id,
    tripId: row.trip_id,
    operatorId: row.operator_id,
    priceCents: row.price_cents,
    currency: row.currency,
    etaMinutes: row.eta_minutes,
    vehicleClass: row.vehicle_class,
    rankScore: row.rank_score,
    expiresAt: row.expires_at,
  };
}

export interface CreateTripInput {
  customerId: string;
  serviceType: string;
  passengerCount: number;
  luggageCount?: number;
  flightNumber?: string;
  organizationId?: string;
  leg: {
    pickupLabel: string;
    pickupLat: number;
    pickupLng: number;
    dropoffLabel?: string;
    dropoffLat?: number;
    dropoffLng?: number;
    scheduledAt: string;
    vehicleClass: string;
  };
  /** Group/wedding bookings (Blueprint §3): multiple vehicle classes + quantities on one trip. */
  vehicleRequests?: { vehicleClass: string; quantity: number }[];
}

export function createTripRequest(input: CreateTripInput): Trip {
  const tripId = newId("trip");
  const now = nowIso();
  db.prepare(
    `INSERT INTO trips (id, customer_id, service_type, status, passenger_count, luggage_count, flight_number, currency, organization_id, created_at, updated_at)
     VALUES (?, ?, ?, 'requested', ?, ?, ?, 'USD', ?, ?, ?)`
  ).run(
    tripId,
    input.customerId,
    input.serviceType,
    input.passengerCount,
    input.luggageCount ?? 0,
    input.flightNumber ?? null,
    input.organizationId ?? null,
    now,
    now
  );

  const legId = newId("leg");
  db.prepare(
    `INSERT INTO legs (id, trip_id, sequence, pickup_label, pickup_lat, pickup_lng, dropoff_label, dropoff_lat, dropoff_lng, scheduled_at, vehicle_class)
     VALUES (?, ?, 0, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    legId,
    tripId,
    input.leg.pickupLabel,
    input.leg.pickupLat,
    input.leg.pickupLng,
    input.leg.dropoffLabel ?? null,
    input.leg.dropoffLat ?? null,
    input.leg.dropoffLng ?? null,
    input.leg.scheduledAt,
    input.leg.vehicleClass
  );

  if (input.vehicleRequests) {
    const insertReq = db.prepare(`INSERT INTO trip_vehicle_requests (id, trip_id, vehicle_class, quantity) VALUES (?, ?, ?, ?)`);
    for (const req of input.vehicleRequests) {
      insertReq.run(newId("vreq"), tripId, req.vehicleClass, req.quantity);
    }
  }

  return getTrip(tripId)!;
}

export function getTrip(id: string): Trip | null {
  const row = db.prepare("SELECT * FROM trips WHERE id = ?").get(id) as any;
  return row ? mapTrip(row) : null;
}

export function listTrips(filters: { customerId?: string; operatorId?: string; organizationId?: string }): Trip[] {
  let sql = "SELECT * FROM trips WHERE 1=1";
  const params: any[] = [];
  if (filters.customerId) {
    sql += " AND customer_id = ?";
    params.push(filters.customerId);
  }
  if (filters.operatorId) {
    sql += " AND operator_id = ?";
    params.push(filters.operatorId);
  }
  if (filters.organizationId) {
    sql += " AND organization_id = ?";
    params.push(filters.organizationId);
  }
  sql += " ORDER BY created_at DESC";
  const rows = db.prepare(sql).all(...params) as any[];
  return rows.map(mapTrip);
}

export function setTripStatus(id: string, status: string) {
  db.prepare("UPDATE trips SET status = ?, updated_at = ? WHERE id = ?").run(status, nowIso(), id);
}

export function confirmTrip(id: string, operatorId: string, totalCents: number, currency: string): Trip {
  db.prepare(
    "UPDATE trips SET status = 'confirmed', operator_id = ?, total_cents = ?, currency = ?, updated_at = ? WHERE id = ?"
  ).run(operatorId, totalCents, currency, nowIso(), id);
  return getTrip(id)!;
}

/** Driver scheduling (Blueprint §8.1): assign one of the operator's own drivers to a confirmed trip. */
export function assignDriver(tripId: string, driverId: string): Trip {
  db.prepare("UPDATE trips SET driver_id = ?, updated_at = ? WHERE id = ?").run(driverId, nowIso(), tripId);
  return getTrip(tripId)!;
}

export function createQuote(input: Omit<Quote, "id">): Quote {
  const id = newId("qt");
  db.prepare(
    `INSERT INTO quotes (id, trip_id, operator_id, price_cents, currency, eta_minutes, vehicle_class, rank_score, expires_at, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(id, input.tripId, input.operatorId, input.priceCents, input.currency, input.etaMinutes, input.vehicleClass, input.rankScore, input.expiresAt, nowIso());
  return { id, ...input };
}

export function listQuotesForTrip(tripId: string): Quote[] {
  const rows = db.prepare("SELECT * FROM quotes WHERE trip_id = ? ORDER BY rank_score DESC").all(tripId) as any[];
  return rows.map(mapQuote);
}

export function getQuote(id: string): Quote | null {
  const row = db.prepare("SELECT * FROM quotes WHERE id = ?").get(id) as any;
  return row ? mapQuote(row) : null;
}

import { db, newId, nowIso } from "../db/client.js";

export interface Message {
  id: string;
  tripId: string;
  senderType: "customer" | "operator";
  senderName: string;
  body: string;
  createdAt: string;
}

function mapMessage(row: any): Message {
  return {
    id: row.id,
    tripId: row.trip_id,
    senderType: row.sender_type,
    senderName: row.sender_name,
    body: row.body,
    createdAt: row.created_at,
  };
}

export function createMessage(input: {
  tripId: string;
  senderType: "customer" | "operator";
  senderName: string;
  body: string;
}): Message {
  const id = newId("msg");
  const createdAt = nowIso();
  db.prepare(`INSERT INTO messages (id, trip_id, sender_type, sender_name, body, created_at) VALUES (?, ?, ?, ?, ?, ?)`).run(
    id,
    input.tripId,
    input.senderType,
    input.senderName,
    input.body,
    createdAt
  );
  return { id, ...input, createdAt };
}

export function listMessagesForTrip(tripId: string): Message[] {
  return (db.prepare("SELECT * FROM messages WHERE trip_id = ? ORDER BY created_at ASC").all(tripId) as any[]).map(mapMessage);
}

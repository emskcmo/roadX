import type { ButtonHTMLAttributes, PropsWithChildren } from "react";

export function Button({
  variant = "primary",
  className = "",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "secondary" | "ghost" }) {
  const base = "inline-flex items-center justify-center gap-2 rounded-full px-6 py-3 text-sm font-medium transition-colors disabled:opacity-40 disabled:cursor-not-allowed";
  const variants = {
    primary: "bg-ink-950 text-ivory-50 hover:bg-ink-800",
    secondary: "bg-brass-500 text-ink-950 hover:bg-brass-400",
    ghost: "bg-transparent text-ink-900 border border-ink-900/15 hover:border-ink-900/40",
  };
  return <button className={`${base} ${variants[variant]} ${className}`} {...props} />;
}

export function Card({ children, className = "" }: PropsWithChildren<{ className?: string }>) {
  return (
    <div className={`rounded-2xl border border-ink-900/8 bg-white shadow-[0_1px_2px_rgba(11,14,20,0.04),0_8px_24px_-12px_rgba(11,14,20,0.12)] ${className}`}>
      {children}
    </div>
  );
}

export function Badge({ children, tone = "neutral" }: PropsWithChildren<{ tone?: "neutral" | "brass" | "success" }>) {
  const tones = {
    neutral: "bg-ink-900/5 text-ink-700",
    brass: "bg-brass-500/15 text-brass-600",
    success: "bg-emerald-500/10 text-emerald-700",
  };
  return <span className={`rounded-full px-2.5 py-1 text-xs font-medium ${tones[tone]}`}>{children}</span>;
}

export function Logo({ className = "" }: { className?: string }) {
  return (
    <div className={`flex items-center gap-2 font-display text-lg tracking-tight ${className}`}>
      <svg width="20" height="20" viewBox="0 0 32 32" fill="none">
        <rect width="32" height="32" rx="7" fill="#0b0e14" />
        <circle cx="9" cy="22" r="2.4" fill="#c9a66b" />
        <circle cx="23" cy="10" r="2.4" fill="#c9a66b" />
        <line x1="9" y1="22" x2="23" y2="10" stroke="#c9a66b" strokeWidth="1.6" />
      </svg>
      Meridian
    </div>
  );
}

export function formatCents(cents: number, currency = "USD"): string {
  return new Intl.NumberFormat("en-US", { style: "currency", currency }).format(cents / 100);
}

import { useEffect, useRef, useState } from "react";
import { api, type Message } from "../lib/api";
import { Button, Card } from "./ui";

export function TripChat({
  tripId,
  senderType,
  senderName,
}: {
  tripId: string;
  senderType: "customer" | "operator";
  senderName: string;
}) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [draft, setDraft] = useState("");
  const [sending, setSending] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  async function refresh() {
    const list = await api.listMessages(tripId);
    setMessages(list);
  }

  useEffect(() => {
    refresh();
    const interval = setInterval(refresh, 4000); // simple polling — Phase 1 has no WebSocket yet
    return () => clearInterval(interval);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tripId]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages.length]);

  async function handleSend() {
    if (!draft.trim()) return;
    setSending(true);
    try {
      await api.sendMessage(tripId, { senderType, senderName, body: draft.trim() });
      setDraft("");
      await refresh();
    } finally {
      setSending(false);
    }
  }

  return (
    <Card className="flex h-80 flex-col p-4">
      <p className="mb-2 text-sm font-medium text-ink-950">Trip chat</p>
      <div className="flex-1 space-y-2 overflow-y-auto pr-1">
        {messages.length === 0 && <p className="text-sm text-ink-500">No messages yet — say hello.</p>}
        {messages.map((m) => (
          <div key={m.id} className={`flex ${m.senderType === senderType ? "justify-end" : "justify-start"}`}>
            <div
              className={`max-w-[80%] rounded-2xl px-3 py-2 text-sm ${
                m.senderType === senderType ? "bg-ink-950 text-ivory-50" : "bg-ink-900/5 text-ink-900"
              }`}
            >
              <p className="mb-0.5 text-[11px] font-medium opacity-70">{m.senderName}</p>
              {m.body}
            </div>
          </div>
        ))}
        <div ref={bottomRef} />
      </div>
      <div className="mt-3 flex gap-2">
        <input
          className="flex-1 rounded-full border border-ink-900/12 px-4 py-2 text-sm"
          placeholder="Message…"
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleSend()}
        />
        <Button variant="secondary" onClick={handleSend} disabled={sending || !draft.trim()}>
          Send
        </Button>
      </div>
    </Card>
  );
}

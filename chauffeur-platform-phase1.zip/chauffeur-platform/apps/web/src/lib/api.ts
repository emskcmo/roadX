const BASE = "/api";

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE}${path}`, {
    ...init,
    headers: { "Content-Type": "application/json", ...(init?.headers ?? {}) },
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error ?? `Request failed: ${res.status}`);
  }
  return res.json();
}

export interface Customer {
  id: string;
  email: string;
  name: string;
  phone: string | null;
}

export interface Quote {
  id: string;
  tripId: string;
  operatorId: string;
  operatorName: string;
  priceCents: number;
  currency: string;
  etaMinutes: number;
  vehicleClass: string;
  rankScore: number;
  ratingAvg: number;
  expiresAt: string;
  breakdown?: { vehicleClass: string; quantity: number; subtotalCents: number }[];
}

export interface Leg {
  id: string;
  pickupLabel: string;
  dropoffLabel: string | null;
  scheduledAt: string;
  vehicleClass: string;
}

export interface VehicleRequest {
  vehicleClass: string;
  quantity: number;
}

export interface Trip {
  id: string;
  status: string;
  serviceType: string;
  passengerCount: number;
  flightNumber: string | null;
  operatorId: string | null;
  driverId: string | null;
  organizationId: string | null;
  totalCents: number | null;
  currency: string;
  legs: Leg[];
  vehicleRequests: VehicleRequest[];
  createdAt: string;
}

export interface Operator {
  id: string;
  displayName: string;
  ratingAvg: number;
  ratingCount: number;
  tier: string;
  vehicles: { id: string; vehicleClass: string; make: string; model: string }[];
  serviceAreas: { label: string }[];
  drivers: Driver[];
}

export interface Driver {
  id: string;
  name: string;
  licenseNumber: string;
  backgroundCheckState: string;
  active: boolean;
}

export interface Organization {
  id: string;
  name: string;
  billingEmail: string;
  createdAt: string;
}

export interface Invoice {
  id: string;
  organizationId: string;
  totalCents: number;
  currency: string;
  status: string;
  createdAt: string;
}

export interface Message {
  id: string;
  tripId: string;
  senderType: "customer" | "operator";
  senderName: string;
  body: string;
  createdAt: string;
}

export const api = {
  createCustomer: (input: { email: string; name: string; phone?: string }) =>
    request<Customer>("/customers", { method: "POST", body: JSON.stringify(input) }),

  requestQuotes: (input: {
    customerId: string;
    serviceType: string;
    vehicleClass: string;
    passengerCount: number;
    luggageCount?: number;
    flightNumber?: string;
    organizationId?: string;
    pickup: { label: string; lat: number; lng: number };
    scheduledAt: string;
  }) => request<{ tripId: string; quotes: Quote[] }>("/trips/quote-request", { method: "POST", body: JSON.stringify(input) }),

  requestGroupQuotes: (input: {
    customerId: string;
    serviceType: "wedding" | "group";
    passengerCount: number;
    pickup: { label: string; lat: number; lng: number };
    scheduledAt: string;
    vehicles: { vehicleClass: string; quantity: number }[];
  }) => request<{ tripId: string; quotes: Quote[] }>("/trips/group-quote-request", { method: "POST", body: JSON.stringify(input) }),

  confirmTrip: (tripId: string, quoteId: string) =>
    request<Trip>(`/trips/${tripId}/confirm`, { method: "POST", body: JSON.stringify({ quoteId }) }),

  getTrip: (tripId: string) => request<Trip & { quotes: Quote[] }>(`/trips/${tripId}`),

  listTrips: (customerId: string) => request<Trip[]>(`/trips?customerId=${customerId}`),

  listOperators: () => request<Operator[]>("/operators"),

  getOperatorTrips: (operatorId: string) => request<Trip[]>(`/operators/${operatorId}/trips`),

  listDrivers: (operatorId: string) => request<Driver[]>(`/operators/${operatorId}/drivers`),

  assignDriver: (tripId: string, driverId: string) =>
    request<Trip>(`/trips/${tripId}/assign-driver`, { method: "POST", body: JSON.stringify({ driverId }) }),

  listOrganizations: () => request<Organization[]>("/organizations"),

  createOrganization: (input: { name: string; billingEmail: string }) =>
    request<Organization>("/organizations", { method: "POST", body: JSON.stringify(input) }),

  getOrgTrips: (orgId: string) => request<Trip[]>(`/organizations/${orgId}/trips`),

  getUnbilled: (orgId: string) => request<{ trips: any[]; totalCents: number; currency: string }>(`/organizations/${orgId}/unbilled`),

  createInvoice: (orgId: string) => request<Invoice>(`/organizations/${orgId}/invoices`, { method: "POST" }),

  listInvoices: (orgId: string) => request<Invoice[]>(`/organizations/${orgId}/invoices`),

  listMessages: (tripId: string) => request<Message[]>(`/trips/${tripId}/messages`),

  sendMessage: (tripId: string, input: { senderType: "customer" | "operator"; senderName: string; body: string }) =>
    request<Message>(`/trips/${tripId}/messages`, { method: "POST", body: JSON.stringify(input) }),
};

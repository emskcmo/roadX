import { BrowserRouter, Routes, Route } from "react-router-dom";
import { SearchPage } from "./pages/customer/SearchPage";
import { GroupBookingPage } from "./pages/customer/GroupBookingPage";
import { ResultsPage } from "./pages/customer/ResultsPage";
import { ConfirmationPage } from "./pages/customer/ConfirmationPage";
import { ReservationsPage } from "./pages/operator/ReservationsPage";
import { FleetPage } from "./pages/operator/FleetPage";
import { DriversPage } from "./pages/operator/DriversPage";
import { FinancialsPage } from "./pages/operator/FinancialsPage";
import { NetworkModePage } from "./pages/operator/NetworkModePage";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Customer booking flow */}
        <Route path="/" element={<SearchPage />} />
        <Route path="/group" element={<GroupBookingPage />} />
        <Route path="/book/:tripId" element={<ResultsPage />} />
        <Route path="/confirmation/:tripId" element={<ConfirmationPage />} />

        {/* Operator dashboard shell */}
        <Route path="/operator" element={<ReservationsPage />} />
        <Route path="/operator/fleet" element={<FleetPage />} />
        <Route path="/operator/drivers" element={<DriversPage />} />
        <Route path="/operator/financials" element={<FinancialsPage />} />
        <Route path="/operator/network" element={<NetworkModePage />} />
      </Routes>
    </BrowserRouter>
  );
}

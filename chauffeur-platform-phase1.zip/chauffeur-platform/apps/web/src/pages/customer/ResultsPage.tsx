import { useEffect, useMemo, useState } from "react";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import { api, type Quote } from "../../lib/api";
import { Badge, Button, Card, Logo, formatCents } from "../../components/ui";

type SortMode = "recommended" | "price" | "rating" | "eta";

export function ResultsPage() {
  const { tripId } = useParams<{ tripId: string }>();
  const location = useLocation();
  const navigate = useNavigate();

  const [quotes, setQuotes] = useState<Quote[]>((location.state as { quotes?: Quote[] } | null)?.quotes ?? []);
  const [loading, setLoading] = useState(quotes.length === 0);
  const [sort, setSort] = useState<SortMode>("recommended");
  const [confirming, setConfirming] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (quotes.length > 0 || !tripId) return;
    api
      .getTrip(tripId)
      .then((trip) => setQuotes(trip.quotes))
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, [tripId, quotes.length]);

  const sorted = useMemo(() => {
    const copy = [...quotes];
    switch (sort) {
      case "price":
        return copy.sort((a, b) => a.priceCents - b.priceCents);
      case "rating":
        return copy.sort((a, b) => b.ratingAvg - a.ratingAvg);
      case "eta":
        return copy.sort((a, b) => a.etaMinutes - b.etaMinutes);
      default:
        return copy.sort((a, b) => b.rankScore - a.rankScore);
    }
  }, [quotes, sort]);

  async function handleSelect(quote: Quote) {
    if (!tripId) return;
    setConfirming(quote.id);
    setError(null);
    try {
      await api.confirmTrip(tripId, quote.id);
      navigate(`/confirmation/${tripId}`);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not confirm booking");
      setConfirming(null);
    }
  }

  return (
    <div className="min-h-screen bg-ivory-50">
      <header className="border-b border-ink-900/8 bg-white">
        <div className="mx-auto flex max-w-4xl items-center justify-between px-6 py-5">
          <Logo />
          <button onClick={() => navigate("/")} className="text-sm text-ink-500 hover:text-ink-900">
            ← New search
          </button>
        </div>
      </header>

      <main className="mx-auto max-w-4xl px-6 py-10">
        <h1 className="font-display text-2xl font-medium text-ink-950">Available chauffeurs</h1>
        <p className="mt-1 text-sm text-ink-500">
          {loading ? "Gathering live quotes…" : `${quotes.length} companies quoted this trip`}
        </p>

        <div className="mt-6 flex flex-wrap gap-2">
          {(
            [
              ["recommended", "Recommended"],
              ["price", "Lowest price"],
              ["rating", "Highest rated"],
              ["eta", "Fastest pickup"],
            ] as [SortMode, string][]
          ).map(([value, label]) => (
            <button
              key={value}
              onClick={() => setSort(value)}
              className={`rounded-full px-4 py-2 text-sm font-medium transition-colors ${
                sort === value ? "bg-ink-950 text-ivory-50" : "bg-white text-ink-700 border border-ink-900/10"
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        {error && <p className="mt-4 text-sm text-red-600">{error}</p>}

        <div className="mt-6 space-y-4">
          {loading && <SkeletonRows />}

          {!loading && sorted.length === 0 && (
            <Card className="p-8 text-center text-ink-500">
              No operators are covering this pickup point in the demo dataset yet — try Kansas City metro.
            </Card>
          )}

          {sorted.map((q, i) => (
            <Card key={q.id} className="flex flex-col gap-4 p-5 md:flex-row md:items-center md:justify-between">
              <div className="flex items-center gap-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-ink-950 font-display text-lg text-ivory-50">
                  {q.operatorName.charAt(0)}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <p className="font-medium text-ink-950">{q.operatorName}</p>
                    {i === 0 && sort === "recommended" && <Badge tone="brass">Recommended</Badge>}
                  </div>
                  <p className="text-sm text-ink-500">
                    ★ {q.ratingAvg.toFixed(1)} · {q.etaMinutes} min ETA ·{" "}
                    {q.breakdown ? q.breakdown.map((b) => `${b.quantity}× ${b.vehicleClass}`).join(" + ") : q.vehicleClass}
                  </p>
                </div>
              </div>

              <div className="flex items-center justify-between gap-6 md:justify-end">
                <p className="font-display text-xl text-ink-950">{formatCents(q.priceCents, q.currency)}</p>
                <Button variant="secondary" onClick={() => handleSelect(q)} disabled={confirming !== null}>
                  {confirming === q.id ? "Booking…" : "Select"}
                </Button>
              </div>
            </Card>
          ))}
        </div>
      </main>
    </div>
  );
}

function SkeletonRows() {
  return (
    <>
      {[0, 1, 2].map((i) => (
        <Card key={i} className="h-24 animate-pulse bg-ink-900/[0.03] p-5" />
      ))}
    </>
  );
}

import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { api, type Trip } from "../../lib/api";
import { Button, Card, Logo, formatCents } from "../../components/ui";
import { TripChat } from "../../components/TripChat";

export function ConfirmationPage() {
  const { tripId } = useParams<{ tripId: string }>();
  const navigate = useNavigate();
  const [trip, setTrip] = useState<Trip | null>(null);

  useEffect(() => {
    if (!tripId) return;
    api.getTrip(tripId).then(setTrip);
  }, [tripId]);

  if (!trip) return null;

  const leg = trip.legs[0];

  return (
    <div className="min-h-screen bg-ivory-50">
      <header className="border-b border-ink-900/8 bg-white">
        <div className="mx-auto max-w-3xl px-6 py-5">
          <Logo />
        </div>
      </header>

      <main className="mx-auto max-w-2xl px-6 py-16 text-center">
        <div className="mx-auto mb-6 flex h-14 w-14 items-center justify-center rounded-full bg-emerald-500/10 text-2xl text-emerald-600">
          ✓
        </div>
        <h1 className="font-display text-3xl font-medium text-ink-950">Your chauffeur is confirmed</h1>
        <p className="mt-2 text-ink-500">A confirmation has been sent — trip #{trip.id.slice(0, 12)}</p>

        <Card className="mt-8 p-6 text-left">
          <Row label="Pickup" value={leg?.pickupLabel} />
          <Row label="Scheduled" value={leg ? new Date(leg.scheduledAt).toLocaleString() : ""} />
          <Row label="Passengers" value={String(trip.passengerCount)} />
          {trip.flightNumber && <Row label="Flight" value={trip.flightNumber} />}
          <Row label="Vehicle" value={leg?.vehicleClass} />
          <div className="mt-4 flex items-center justify-between border-t border-ink-900/8 pt-4">
            <span className="font-medium text-ink-950">Total</span>
            <span className="font-display text-xl text-ink-950">
              {trip.totalCents !== null ? formatCents(trip.totalCents, trip.currency) : "—"}
            </span>
          </div>
        </Card>

        <Button className="mt-8" onClick={() => navigate("/")}>
          Book another trip
        </Button>

        <div className="mt-8 text-left">
          <TripChat tripId={trip.id} senderType="customer" senderName="Jordan Ellis" />
        </div>
      </main>
    </div>
  );
}

function Row({ label, value }: { label: string; value?: string }) {
  return (
    <div className="flex items-center justify-between py-2 text-sm">
      <span className="text-ink-500">{label}</span>
      <span className="font-medium text-ink-900">{value}</span>
    </div>
  );
}

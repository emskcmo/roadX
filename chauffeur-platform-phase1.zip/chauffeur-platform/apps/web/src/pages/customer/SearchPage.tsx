import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { api, type Organization } from "../../lib/api";
import { Button, Card, Logo } from "../../components/ui";

// Kansas City metro — matches the seeded demo operators (Blueprint
// docs/data-model.prisma seed). A real build would geocode whatever
// address the person types; this scaffold keeps geocoding out of
// scope and offers a couple of known-good demo pickup points.
const DEMO_LOCATIONS = [
  { label: "Kansas City International Airport (MCI)", lat: 39.2976, lng: -94.7139 },
  { label: "Country Club Plaza, Kansas City, MO", lat: 39.0392, lng: -94.5947 },
  { label: "Downtown Kansas City Convention Center", lat: 39.0989, lng: -94.5843 },
];

const SERVICE_TYPES = [
  { value: "airport", label: "Airport transfer" },
  { value: "hourly", label: "Hourly / as-directed" },
  { value: "point_to_point", label: "Point to point" },
  { value: "long_distance", label: "Long distance" },
];

const VEHICLE_CLASSES = [
  { value: "sedan", label: "Executive Sedan", blurb: "1–3 passengers" },
  { value: "suv", label: "Executive SUV", blurb: "1–6 passengers" },
];

export function SearchPage() {
  const navigate = useNavigate();
  const [serviceType, setServiceType] = useState("airport");
  const [vehicleClass, setVehicleClass] = useState("sedan");
  const [pickupIdx, setPickupIdx] = useState(0);
  const [passengerCount, setPassengerCount] = useState(1);
  const [flightNumber, setFlightNumber] = useState("");
  const [date, setDate] = useState("2026-07-10");
  const [time, setTime] = useState("14:30");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [organizations, setOrganizations] = useState<Organization[]>([]);
  const [organizationId, setOrganizationId] = useState<string>("");

  useEffect(() => {
    api.listOrganizations().then(setOrganizations);
  }, []);

  async function handleSearch() {
    setLoading(true);
    setError(null);
    try {
      const customer = await api.createCustomer({ email: "demo.customer@example.com", name: "Jordan Ellis" });
      const pickup = DEMO_LOCATIONS[pickupIdx];
      const scheduledAt = new Date(`${date}T${time}:00`).toISOString();

      const result = await api.requestQuotes({
        customerId: customer.id,
        serviceType,
        vehicleClass,
        passengerCount,
        flightNumber: serviceType === "airport" ? flightNumber || undefined : undefined,
        organizationId: organizationId || undefined,
        pickup,
        scheduledAt,
      });

      navigate(`/book/${result.tripId}`, { state: { quotes: result.quotes } });
    } catch (e) {
      setError(e instanceof Error ? e.message : "Something went wrong");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-ink-950">
      {/* Hero */}
      <header className="mx-auto max-w-6xl px-6 py-8">
        <Logo className="text-ivory-50" />
      </header>

      <section className="mx-auto max-w-6xl px-6 pb-24 pt-6">
        <h1 className="font-display max-w-2xl text-4xl font-medium leading-tight text-ivory-50 md:text-5xl">
          Executive ground transportation, coast to coast.
        </h1>
        <p className="mt-4 max-w-xl text-ivory-200/70">
          Live quotes from verified, licensed chauffeur companies near your pickup — compared instantly, booked in seconds.
        </p>

        <Card className="mt-10 p-6 md:p-8">
          <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
            <Field label="Service type">
              <select
                className="input"
                value={serviceType}
                onChange={(e) => setServiceType(e.target.value)}
              >
                {SERVICE_TYPES.map((s) => (
                  <option key={s.value} value={s.value}>
                    {s.label}
                  </option>
                ))}
              </select>
            </Field>

            <Field label="Vehicle class">
              <select className="input" value={vehicleClass} onChange={(e) => setVehicleClass(e.target.value)}>
                {VEHICLE_CLASSES.map((v) => (
                  <option key={v.value} value={v.value}>
                    {v.label} — {v.blurb}
                  </option>
                ))}
              </select>
            </Field>

            <Field label="Pickup" className="md:col-span-2">
              <select className="input" value={pickupIdx} onChange={(e) => setPickupIdx(Number(e.target.value))}>
                {DEMO_LOCATIONS.map((loc, i) => (
                  <option key={loc.label} value={i}>
                    {loc.label}
                  </option>
                ))}
              </select>
            </Field>

            <Field label="Date">
              <input type="date" className="input" value={date} onChange={(e) => setDate(e.target.value)} />
            </Field>
            <Field label="Time">
              <input type="time" className="input" value={time} onChange={(e) => setTime(e.target.value)} />
            </Field>

            <Field label="Passengers">
              <input
                type="number"
                min={1}
                max={14}
                className="input"
                value={passengerCount}
                onChange={(e) => setPassengerCount(Number(e.target.value))}
              />
            </Field>

            {serviceType === "airport" && (
              <Field label="Flight number (optional)">
                <input
                  type="text"
                  placeholder="e.g. AA1234"
                  className="input"
                  value={flightNumber}
                  onChange={(e) => setFlightNumber(e.target.value)}
                />
              </Field>
            )}

            <Field label="Booking for (optional)" className="md:col-span-2">
              <select className="input" value={organizationId} onChange={(e) => setOrganizationId(e.target.value)}>
                <option value="">Myself</option>
                {organizations.map((org) => (
                  <option key={org.id} value={org.id}>
                    {org.name} (corporate account)
                  </option>
                ))}
              </select>
            </Field>
          </div>

          {error && <p className="mt-4 text-sm text-red-600">{error}</p>}

          <div className="mt-8 flex items-center justify-between">
            <p className="text-xs text-ink-500">Demo market: Kansas City metro (seeded operators)</p>
            <Button onClick={handleSearch} disabled={loading}>
              {loading ? "Finding chauffeurs…" : "See live quotes"}
            </Button>
          </div>
        </Card>

        <button
          onClick={() => navigate("/group")}
          className="mt-6 text-sm font-medium text-brass-400 hover:text-brass-300"
        >
          Planning a wedding or group event? Request multiple vehicles →
        </button>
      </section>

      <style>{`.input {
        width: 100%;
        border-radius: 0.75rem;
        border: 1px solid rgba(11,14,20,0.12);
        padding: 0.65rem 0.9rem;
        font-size: 0.925rem;
        background: white;
      }
      .input:focus { outline: 2px solid #c9a66b; outline-offset: 1px; }`}</style>
    </div>
  );
}

function Field({ label, children, className = "" }: { label: string; children: React.ReactNode; className?: string }) {
  return (
    <label className={`block text-sm ${className}`}>
      <span className="mb-1.5 block font-medium text-ink-700">{label}</span>
      {children}
    </label>
  );
}

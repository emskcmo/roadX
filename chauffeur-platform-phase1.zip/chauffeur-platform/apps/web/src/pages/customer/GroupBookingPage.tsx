import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "../../lib/api";
import { Button, Card, Logo } from "../../components/ui";

const PICKUP = { label: "Downtown Kansas City Convention Center", lat: 39.0989, lng: -94.5843 };
const VEHICLE_CLASSES = ["sedan", "suv", "sprinter", "stretch", "motor_coach"] as const;

interface Row {
  vehicleClass: (typeof VEHICLE_CLASSES)[number];
  quantity: number;
}

export function GroupBookingPage() {
  const navigate = useNavigate();
  const [serviceType, setServiceType] = useState<"wedding" | "group">("wedding");
  const [passengerCount, setPassengerCount] = useState(10);
  const [date, setDate] = useState("2026-08-15");
  const [time, setTime] = useState("15:00");
  const [rows, setRows] = useState<Row[]>([{ vehicleClass: "sedan", quantity: 2 }]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const totalVehicles = useMemo(() => rows.reduce((s, r) => s + r.quantity, 0), [rows]);

  function updateRow(i: number, patch: Partial<Row>) {
    setRows((prev) => prev.map((r, idx) => (idx === i ? { ...r, ...patch } : r)));
  }

  function addRow() {
    setRows((prev) => [...prev, { vehicleClass: "suv", quantity: 1 }]);
  }

  function removeRow(i: number) {
    setRows((prev) => prev.filter((_, idx) => idx !== i));
  }

  async function handleSearch() {
    setLoading(true);
    setError(null);
    try {
      const customer = await api.createCustomer({ email: "demo.customer@example.com", name: "Jordan Ellis" });
      const scheduledAt = new Date(`${date}T${time}:00`).toISOString();

      const result = await api.requestGroupQuotes({
        customerId: customer.id,
        serviceType,
        passengerCount,
        pickup: PICKUP,
        scheduledAt,
        vehicles: rows,
      });

      navigate(`/book/${result.tripId}`, { state: { quotes: result.quotes } });
    } catch (e) {
      setError(e instanceof Error ? e.message : "Something went wrong");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-ink-950">
      <header className="mx-auto flex max-w-4xl items-center justify-between px-6 py-8">
        <Logo className="text-ivory-50" />
        <button onClick={() => navigate("/")} className="text-sm text-ivory-200/60 hover:text-ivory-50">
          ← Standard booking
        </button>
      </header>

      <section className="mx-auto max-w-4xl px-6 pb-24">
        <h1 className="font-display max-w-xl text-3xl font-medium text-ivory-50 md:text-4xl">
          Weddings &amp; group transportation
        </h1>
        <p className="mt-3 max-w-lg text-ivory-200/70">
          Request several vehicles for one event — we'll bundle a quote from operators who can field your whole order at
          once.
        </p>

        <Card className="mt-8 p-6 md:p-8">
          <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
            <Field label="Occasion">
              <select className="input" value={serviceType} onChange={(e) => setServiceType(e.target.value as "wedding" | "group")}>
                <option value="wedding">Wedding</option>
                <option value="group">Group / corporate event</option>
              </select>
            </Field>
            <Field label="Total guests">
              <input
                type="number"
                min={1}
                className="input"
                value={passengerCount}
                onChange={(e) => setPassengerCount(Number(e.target.value))}
              />
            </Field>
            <Field label="Date">
              <input type="date" className="input" value={date} onChange={(e) => setDate(e.target.value)} />
            </Field>
            <Field label="Time">
              <input type="time" className="input" value={time} onChange={(e) => setTime(e.target.value)} />
            </Field>
          </div>

          <div className="mt-6">
            <p className="mb-2 text-sm font-medium text-ink-700">Vehicles needed</p>
            <div className="space-y-3">
              {rows.map((row, i) => (
                <div key={i} className="flex items-center gap-3">
                  <select
                    className="input flex-1"
                    value={row.vehicleClass}
                    onChange={(e) => updateRow(i, { vehicleClass: e.target.value as Row["vehicleClass"] })}
                  >
                    {VEHICLE_CLASSES.map((v) => (
                      <option key={v} value={v}>
                        {v.replace("_", " ")}
                      </option>
                    ))}
                  </select>
                  <input
                    type="number"
                    min={1}
                    className="input w-24"
                    value={row.quantity}
                    onChange={(e) => updateRow(i, { quantity: Number(e.target.value) })}
                  />
                  {rows.length > 1 && (
                    <button onClick={() => removeRow(i)} className="text-sm text-ink-500 hover:text-red-600">
                      Remove
                    </button>
                  )}
                </div>
              ))}
            </div>
            <button onClick={addRow} className="mt-3 text-sm font-medium text-brass-600 hover:text-brass-500">
              + Add another vehicle class
            </button>
          </div>

          {error && <p className="mt-4 text-sm text-red-600">{error}</p>}

          <div className="mt-8 flex items-center justify-between">
            <p className="text-xs text-ink-500">{totalVehicles} vehicle(s) requested · Demo market: Kansas City metro</p>
            <Button onClick={handleSearch} disabled={loading}>
              {loading ? "Finding operators…" : "See bundled quotes"}
            </Button>
          </div>
        </Card>
      </section>

      <style>{`.input {
        width: 100%;
        border-radius: 0.75rem;
        border: 1px solid rgba(11,14,20,0.12);
        padding: 0.65rem 0.9rem;
        font-size: 0.925rem;
        background: white;
      }
      .input:focus { outline: 2px solid #c9a66b; outline-offset: 1px; }`}</style>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block text-sm">
      <span className="mb-1.5 block font-medium text-ink-700">{label}</span>
      {children}
    </label>
  );
}

import type { PropsWithChildren } from "react";
import { NavLink } from "react-router-dom";
import { Logo } from "../../components/ui";

const NAV = [
  { to: "/operator", label: "Reservations", end: true },
  { to: "/operator/fleet", label: "Fleet" },
  { to: "/operator/drivers", label: "Drivers" },
  { to: "/operator/financials", label: "Financials" },
  { to: "/operator/network", label: "Network Mode" },
];

export function DashboardLayout({ children }: PropsWithChildren) {
  return (
    <div className="flex min-h-screen bg-ivory-50">
      <aside className="hidden w-60 shrink-0 border-r border-ink-900/8 bg-white md:block">
        <div className="px-6 py-6">
          <Logo />
        </div>
        <nav className="px-3">
          {NAV.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) =>
                `mb-1 block rounded-lg px-3 py-2.5 text-sm font-medium transition-colors ${
                  isActive ? "bg-ink-950 text-ivory-50" : "text-ink-700 hover:bg-ink-900/5"
                }`
              }
            >
              {item.label}
            </NavLink>
          ))}
        </nav>
        <div className="absolute bottom-6 left-6 right-[calc(100%-15rem+1.5rem)] px-0">
          <p className="text-xs text-ink-500">Signed in as</p>
          <p className="text-sm font-medium text-ink-900">Heartland Executive</p>
        </div>
      </aside>

      <div className="flex-1">
        <header className="flex items-center justify-between border-b border-ink-900/8 bg-white px-8 py-4 md:hidden">
          <Logo />
        </header>
        <main className="mx-auto max-w-5xl px-6 py-8 md:px-10 md:py-10">{children}</main>
      </div>
    </div>
  );
}

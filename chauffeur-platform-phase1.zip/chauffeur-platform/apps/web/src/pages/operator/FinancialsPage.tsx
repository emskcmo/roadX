import { useEffect, useState } from "react";
import { api, type Invoice, type Organization } from "../../lib/api";
import { Badge, Button, Card, formatCents } from "../../components/ui";
import { DashboardLayout } from "./DashboardLayout";

export function FinancialsPage() {
  const [organizations, setOrganizations] = useState<Organization[]>([]);
  const [selectedOrgId, setSelectedOrgId] = useState<string>("");
  const [unbilled, setUnbilled] = useState<{ trips: any[]; totalCents: number; currency: string } | null>(null);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [creating, setCreating] = useState(false);

  useEffect(() => {
    api.listOrganizations().then((orgs) => {
      setOrganizations(orgs);
      if (orgs[0]) setSelectedOrgId(orgs[0].id);
    });
  }, []);

  useEffect(() => {
    if (!selectedOrgId) return;
    api.getUnbilled(selectedOrgId).then(setUnbilled);
    api.listInvoices(selectedOrgId).then(setInvoices);
  }, [selectedOrgId]);

  async function handleCreateInvoice() {
    setCreating(true);
    try {
      await api.createInvoice(selectedOrgId);
      setUnbilled(await api.getUnbilled(selectedOrgId));
      setInvoices(await api.listInvoices(selectedOrgId));
    } catch {
      // nothing_to_bill is the expected error when there's no unbilled balance
    } finally {
      setCreating(false);
    }
  }

  return (
    <DashboardLayout>
      <h1 className="font-display text-2xl font-medium text-ink-950">Financials</h1>
      <p className="mt-1 text-sm text-ink-500">
        Stripe Connect payouts and accounting exports (Blueprint §8.1, §11) are a later-phase build. Corporate
        consolidated invoicing (§6.6) is live below.
      </p>

      {organizations.length > 0 && (
        <Card className="mt-6 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-ink-700">Corporate account</p>
              <select
                className="mt-1 rounded-lg border border-ink-900/12 px-3 py-2 text-sm"
                value={selectedOrgId}
                onChange={(e) => setSelectedOrgId(e.target.value)}
              >
                {organizations.map((org) => (
                  <option key={org.id} value={org.id}>
                    {org.name}
                  </option>
                ))}
              </select>
            </div>
            <div className="text-right">
              <p className="text-sm text-ink-500">Unbilled balance</p>
              <p className="font-display text-2xl text-ink-950">
                {unbilled ? formatCents(unbilled.totalCents, unbilled.currency) : "—"}
              </p>
            </div>
          </div>

          <div className="mt-4 flex items-center justify-between border-t border-ink-900/8 pt-4">
            <p className="text-sm text-ink-500">{unbilled?.trips.length ?? 0} unbilled trip(s)</p>
            <Button variant="secondary" onClick={handleCreateInvoice} disabled={creating || !unbilled?.trips.length}>
              {creating ? "Generating…" : "Generate invoice"}
            </Button>
          </div>
        </Card>
      )}

      <div className="mt-6 space-y-3">
        {invoices.map((inv) => (
          <Card key={inv.id} className="flex items-center justify-between p-4">
            <div>
              <p className="font-medium text-ink-950">Invoice #{inv.id.slice(0, 12)}</p>
              <p className="text-sm text-ink-500">{new Date(inv.createdAt).toLocaleDateString()}</p>
            </div>
            <div className="flex items-center gap-3">
              <Badge tone="brass">{inv.status}</Badge>
              <p className="font-display text-lg text-ink-950">{formatCents(inv.totalCents, inv.currency)}</p>
            </div>
          </Card>
        ))}
      </div>
    </DashboardLayout>
  );
}

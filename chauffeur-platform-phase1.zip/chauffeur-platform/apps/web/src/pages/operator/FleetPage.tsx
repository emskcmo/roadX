import { useEffect, useState } from "react";
import { api, type Operator } from "../../lib/api";
import { Card, Badge } from "../../components/ui";
import { DashboardLayout } from "./DashboardLayout";

export function FleetPage() {
  const [operator, setOperator] = useState<Operator | null>(null);

  useEffect(() => {
    api.listOperators().then((operators) => setOperator(operators[0] ?? null));
  }, []);

  return (
    <DashboardLayout>
      <h1 className="font-display text-2xl font-medium text-ink-950">Fleet</h1>
      <p className="mt-1 text-sm text-ink-500">Vehicles registered to {operator?.displayName ?? "your company"}</p>

      <div className="mt-6 grid grid-cols-1 gap-4 md:grid-cols-2">
        {operator?.vehicles.map((v) => (
          <Card key={v.id} className="p-5">
            <div className="flex items-center justify-between">
              <p className="font-medium text-ink-950">
                {v.make} {v.model}
              </p>
              <Badge tone="brass">{v.vehicleClass}</Badge>
            </div>
          </Card>
        ))}
      </div>

      <Card className="mt-8 p-6">
        <p className="text-sm text-ink-500">
          Maintenance tracking, document-expiration alerts, and route optimization (Blueprint §8.1) are scoped for a later
          phase once fleet volume justifies the added workflow.
        </p>
      </Card>
    </DashboardLayout>
  );
}

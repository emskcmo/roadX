import { useEffect, useState } from "react";
import { api, type Operator } from "../../lib/api";
import { Badge, Card } from "../../components/ui";
import { DashboardLayout } from "./DashboardLayout";

export function DriversPage() {
  const [operator, setOperator] = useState<Operator | null>(null);

  useEffect(() => {
    api.listOperators().then((operators) => setOperator(operators[0] ?? null));
  }, []);

  return (
    <DashboardLayout>
      <h1 className="font-display text-2xl font-medium text-ink-950">Drivers</h1>
      <p className="mt-1 text-sm text-ink-500">Roster for {operator?.displayName ?? "your company"}</p>

      <div className="mt-6 space-y-3">
        {operator?.drivers.map((d) => (
          <Card key={d.id} className="flex items-center justify-between p-4">
            <div>
              <p className="font-medium text-ink-950">{d.name}</p>
              <p className="text-sm text-ink-500">License {d.licenseNumber}</p>
            </div>
            <Badge tone={d.backgroundCheckState === "passed" ? "success" : "neutral"}>
              Background check: {d.backgroundCheckState}
            </Badge>
          </Card>
        ))}
      </div>

      <Card className="mt-8 p-6">
        <p className="text-sm text-ink-500">
          Shift scheduling and hours-of-service tracking (Blueprint §8.1) are scoped for a later phase — driver
          assignment to confirmed trips is live today from the Reservations page.
        </p>
      </Card>
    </DashboardLayout>
  );
}

import { useEffect, useState } from "react";
import { api, type Driver, type Operator, type Trip } from "../../lib/api";
import { Badge, Card, formatCents } from "../../components/ui";
import { DashboardLayout } from "./DashboardLayout";

const STATUS_TONE: Record<string, "neutral" | "brass" | "success"> = {
  requested: "neutral",
  quoted: "neutral",
  confirmed: "brass",
  completed: "success",
};

export function ReservationsPage() {
  const [operator, setOperator] = useState<Operator | null>(null);
  const [trips, setTrips] = useState<Trip[]>([]);
  const [drivers, setDrivers] = useState<Driver[]>([]);
  const [loading, setLoading] = useState(true);
  const [assigning, setAssigning] = useState<string | null>(null);

  async function refresh(operatorId: string) {
    setTrips(await api.getOperatorTrips(operatorId));
  }

  useEffect(() => {
    api.listOperators().then(async (operators) => {
      const first = operators[0] ?? null;
      setOperator(first);
      if (first) {
        setDrivers(first.drivers);
        await refresh(first.id);
      }
      setLoading(false);
    });
  }, []);

  async function handleAssign(tripId: string, driverId: string) {
    setAssigning(tripId);
    try {
      await api.assignDriver(tripId, driverId);
      if (operator) await refresh(operator.id);
    } finally {
      setAssigning(null);
    }
  }

  return (
    <DashboardLayout>
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-medium text-ink-950">Reservations</h1>
          <p className="mt-1 text-sm text-ink-500">
            {operator ? `${operator.displayName} · ${operator.tier} tier · ★ ${operator.ratingAvg.toFixed(1)}` : ""}
          </p>
        </div>
      </div>

      {loading && <p className="text-sm text-ink-500">Loading…</p>}

      {!loading && trips.length === 0 && (
        <Card className="p-8 text-center text-ink-500">
          No reservations yet. Confirmed bookings from the customer app will show up here in real time.
        </Card>
      )}

      <div className="space-y-3">
        {trips.map((trip) => (
          <Card key={trip.id} className="flex flex-col gap-3 p-5 md:flex-row md:items-center md:justify-between">
            <div>
              <div className="flex items-center gap-2">
                <p className="font-medium text-ink-950">{trip.legs[0]?.pickupLabel ?? "—"}</p>
                <Badge tone={STATUS_TONE[trip.status] ?? "neutral"}>{trip.status}</Badge>
                {trip.organizationId && <Badge tone="brass">Corporate</Badge>}
              </div>
              <p className="mt-1 text-sm text-ink-500">
                {trip.serviceType.replace("_", " ")} · {trip.passengerCount} pax
                {trip.flightNumber ? ` · flight ${trip.flightNumber}` : ""}
                {trip.legs[0] ? ` · ${new Date(trip.legs[0].scheduledAt).toLocaleString()}` : ""}
              </p>
              {trip.vehicleRequests.length > 0 && (
                <p className="mt-1 text-xs text-ink-500">
                  {trip.vehicleRequests.map((v) => `${v.quantity}× ${v.vehicleClass}`).join(" + ")}
                </p>
              )}
            </div>

            <div className="flex items-center gap-4">
              {trip.status === "confirmed" && (
                <select
                  className="rounded-lg border border-ink-900/12 px-3 py-2 text-sm"
                  value={trip.driverId ?? ""}
                  disabled={assigning === trip.id}
                  onChange={(e) => e.target.value && handleAssign(trip.id, e.target.value)}
                >
                  <option value="">Assign driver…</option>
                  {drivers.map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.name}
                    </option>
                  ))}
                </select>
              )}
              <p className="font-display text-lg text-ink-950">
                {trip.totalCents !== null ? formatCents(trip.totalCents, trip.currency) : "—"}
              </p>
            </div>
          </Card>
        ))}
      </div>
    </DashboardLayout>
  );
}

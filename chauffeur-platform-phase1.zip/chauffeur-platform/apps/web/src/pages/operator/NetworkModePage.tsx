import { Badge, Card } from "../../components/ui";
import { DashboardLayout } from "./DashboardLayout";

export function NetworkModePage() {
  return (
    <DashboardLayout>
      <div className="flex items-center gap-3">
        <h1 className="font-display text-2xl font-medium text-ink-950">Network Mode</h1>
        <Badge tone="brass">Phase 2</Badge>
      </div>
      <p className="mt-1 text-sm text-ink-500">The platform's core reliability differentiator — Blueprint §5</p>

      <Card className="mt-6 p-8">
        <p className="text-ink-700">
          Network Mode intentionally isn't built yet. Per the phased roadmap (Blueprint §14), it needs real operator
          density in a market before it can function as a genuine marketplace — launching it with one or two operators
          per metro would just mean a company negotiating with itself.
        </p>
        <ul className="mt-4 list-inside list-disc space-y-1.5 text-sm text-ink-500">
          <li>Release-to-network flow when an operator can't fulfill a confirmed trip</li>
          <li>Cascading distribution: preferred partners → open network → white-label sub-networks</li>
          <li>Live marketplace feed with one-click accept</li>
          <li>Referral commission engine (with the take-rate ceiling from §5.8 modeled before launch)</li>
        </ul>
      </Card>
    </DashboardLayout>
  );
}

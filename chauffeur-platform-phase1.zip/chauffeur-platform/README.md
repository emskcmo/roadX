# Chauffeur Marketplace — Phase 0 + Phase 1

A running scaffold of the platform described in `docs/blueprint.md`: a two-sided
marketplace connecting customers with verified, independent limousine
companies.

## What's actually working right now

**Phase 0 — Foundation**
- Operator onboarding & verification, vehicles, service areas, pricing rules
- The **Distribution Engine** (live quote matching + composite ranking, Blueprint §4.4)
- Customer booking flow: search → live ranked quotes → confirm → confirmation
- Operator dashboard shell: Reservations, Fleet (real data)

**Phase 1 — Corporate booking, group/wedding booking, drivers, chat**
- Simple corporate accounts (Blueprint §6): tag a trip to an organization,
  view unbilled trips, generate a consolidated invoice
- Group/wedding multi-vehicle booking (Blueprint §3): request several vehicle
  classes at once, get a bundled quote from operators whose fleet can cover
  the whole order — not just single-vehicle matching
- Driver scheduling (Blueprint §8.1): assign one of an operator's own drivers
  to a confirmed trip
- In-app chat (Blueprint §3.1): a simple polled message thread per trip,
  visible on both the customer confirmation page and (soon) the operator side

## What's intentionally not built yet

- Real authentication — there's a stand-in "create-or-get customer by email"
- Payments (Stripe Connect) — pricing/settlement math exists, the actual
  charge/payout wiring doesn't
- Network Mode (§5) and the full Corporate Network Mode (§6) — enterprise
  RBAC, approval chains, SSO, and ERP integrations are scoped for later
  phases per the roadmap; the data model already has fields reserved for
  them so they extend this schema rather than replace it
- Real geocoding — the demo uses a fixed list of Kansas City metro pickup
  points that match the seeded operators
- Real-time chat (current implementation polls every 4s, not WebSocket)

## A note on the database

This scaffold runs on Node's built-in `node:sqlite` (zero native builds, zero
external downloads — it just works). **`docs/data-model.prisma` is the
canonical, Postgres-ready schema** from the blueprint; `apps/api/src/db/schema.sql`
mirrors it by hand for this Phase 0/1 runtime. When you're ready to deploy for
real:

1. `npm install prisma @prisma/client` in `apps/api`
2. Drop `docs/data-model.prisma` in as `apps/api/prisma/schema.prisma`, change
   `datasource.provider` to `"postgresql"`, point `DATABASE_URL` at a real
   Postgres instance, and add the Phase 1 tables (`organizations`, `invoices`,
   `trip_vehicle_requests`, `messages`) that currently only live in
   `schema.sql`
3. Port `apps/api/src/repositories/*.ts` to Prisma client calls — the function
   signatures and shapes already match, so this is a mechanical swap, not a
   redesign

(This detour exists because the sandbox this was built in blocks the network
call Prisma's CLI makes to fetch its query engine binary. Your own machine
won't have that problem — Prisma is a perfectly good choice for Postgres.)

**If you change `schema.sql`, delete `dev.db` and re-run `npm run seed`** —
tables are created with `CREATE TABLE IF NOT EXISTS`, so an existing dev.db
won't pick up new columns automatically.

## Running it

**Backend:**
```bash
cd apps/api
npm install
npm run seed      # seeds 3 demo operators + a demo corporate account in Kansas City
npm run dev        # http://localhost:4000
```

**Frontend** (separate terminal):
```bash
cd apps/web
npm install
npm run dev        # http://localhost:5173
```

Open `http://localhost:5173` for the customer booking flow (there's a link to
the group/wedding flow at the bottom of the search form), or
`http://localhost:5173/operator` for the operator dashboard.

## Project structure

```
apps/
  api/                    Node + TypeScript + Express
    src/
      db/                 node:sqlite client + schema.sql + seed script
      repositories/       data access (swap for Prisma client later)
        operatorsRepo.ts        operators, vehicles, service areas, pricing, drivers
        tripsRepo.ts             trips, legs, quotes, group-booking vehicle requests
        organizationsRepo.ts     corporate accounts + invoicing
        messagesRepo.ts          trip chat
        customersRepo.ts
      services/
        distributionEngine.ts   The core matching/ranking engine (Blueprint §4.4) —
                                 the ONE place Network Mode and Corporate Mode
                                 should plug into later, not a second matching system.
                                 Also powers group-booking bundle quotes.
        pricingEngine.ts        Rule-based fare calculation (Blueprint §10, Phase 1)
      routes/             operators, trips, customers, organizations
  web/                    React + Vite + Tailwind v4
    src/
      components/
        ui.tsx             shared primitives (Button, Card, Badge, Logo)
        TripChat.tsx        reusable chat widget
      pages/customer/     SearchPage → ResultsPage → ConfirmationPage
                           GroupBookingPage (multi-vehicle wedding/group flow)
      pages/operator/     DashboardLayout + Reservations (+ driver assignment) /
                           Fleet / Drivers (real roster) / Financials (+ corporate
                           invoicing) / NetworkMode (Phase 2 placeholder)
docs/
  blueprint.md            The full product & architecture blueprint
  data-model.prisma       Canonical Postgres-ready schema
```

## Next steps toward Phase 2

Per the blueprint roadmap (§14): Network Mode — but only once there's real
operator density per market (§14 explicitly warns against launching it with
one or two operators per metro). Also: dynamic pricing recommendations,
demand forecasting, and a learned ranking model once there's real trip
outcome data to train on.


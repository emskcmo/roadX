# [Platform Name TBD] — Product & Architecture Blueprint
### A Premium Chauffeur Marketplace for Independent Limousine Companies Across the U.S.

*Version 0.2 — Concept-stage blueprint (adds Network Mode + Corporate Network Mode)*

---

## 1. Executive Summary

This platform is a **two-sided marketplace** connecting travelers who need premium ground transportation with independent, licensed limousine and chauffeur companies. The platform does not own vehicles or employ drivers — it provides the demand (customers), the software (booking, dispatch, payments, CRM), and the trust layer (verification, ratings, insurance checks), while operator-partners provide the supply (fleets, drivers, local expertise).

The closest structural analogy is **Booking.com for hotels** or **Turo for cars**, applied to chauffeured transportation, with the customer-facing polish of **Blacklane** and the real-time logistics of **Uber Black**.

Four things have to be true simultaneously for this to work:

1. **Customers get airline-level reliability and Blacklane-level polish**, regardless of which local operator fulfills the ride.
2. **Operators get software so good that running their business without it feels backward** — this is the retention engine, not just a booking feed.
3. **The matching engine must be defensible** — if it were purely lowest-price-wins, it becomes a commodity dispatch board. Reliability, quality, and fit need to matter as much as price.
4. **No booking is ever truly lost** — if the operator holding a reservation can't fulfill it, the platform's own operator network absorbs it (§5) rather than the customer being told "sorry, no cars available." This is the structural feature that changes reliability from "as good as the assigned operator" to "as good as the entire network," and it's the single biggest lever available for beating Blacklane on coverage and dependability.

---

## 2. Marketplace Model

### 2.1 Roles

| Role | Description |
|---|---|
| **Customer** | Individual, executive assistant, travel manager, or corporate travel program booking rides |
| **Operator (Partner)** | A licensed limousine/chauffeur company that owns/manages vehicles and drivers |
| **Driver (Chauffeur)** | Employed or contracted by an Operator; not a direct platform user in the Turo/Uber sense — drivers work *for* operators, not for the platform |
| **Corporate Account** | An organization (business, hotel, DMC, agency, etc.) booking on behalf of employees, guests, or clients — see §6 |
| **Platform** | Owns the demand, brand, trust layer, payments, and software |

This is a deliberate and important distinction from Uber: **drivers are not gig workers of the platform.** They are employees or contractors of the Operator. This avoids a huge amount of labor-classification risk and matches how the limousine industry actually works today (affiliate networks, NLA, etc.), while giving customers a single consistent brand experience.

### 2.2 Operator Onboarding & Verification

Before an operator can receive bookings, they must pass a verification pipeline:

- **Business verification**: business license, DOT/FMCSA number (if applicable), state PUC/limousine permit, EIN, insurance certificate (with minimum coverage thresholds), individual vehicle registrations
- **Vehicle verification**: photos, year/make/model, class (sedan, SUV, sprinter, stretch, motor coach), inspection certificates, insurance riders per vehicle
- **Driver verification**: chauffeur license/permit where required, background check (via a service like Checkr), TSA precheck for airport-adjacent zones where relevant
- **Financial verification**: Stripe Connect onboarding (KYC, bank account, tax ID) for payouts
- **Service area & capability declaration**: geofenced coverage zones, vehicle classes offered, service types offered (airport, hourly, wedding, etc.)
- **Insurance monitoring**: expiration tracking with auto-suspension and renewal reminders

This same verification gate is what qualifies an operator for **Network Mode** (§5) — only verified, in-good-standing operators can see or accept shared reservations. Operators are tiered (see §8) based on ongoing performance, not just onboarding — verification is a gate, tiering is a living score.

### 2.3 What Each Operator Controls

- Fleet (vehicle types, classes, photos, amenities, capacity)
- Driver roster and scheduling
- Pricing (base rates, per-mile/per-hour, minimums, surge participation, seasonal rates)
- Availability calendar and blackout dates
- Service area (drawn geofences, airport zones, city-pair long-distance lanes)
- Business hours and dispatch rules (auto-accept vs. manual accept, lead-time minimums)
- Cancellation policy (within platform-defined min/max bounds — see §2.4)
- Whether, and how, an unfulfillable reservation gets released into Network Mode (§5.5)

### 2.4 Guardrails the Platform Enforces (Non-Negotiable)

To keep the customer experience consistent across thousands of independent operators, some things are **not** operator-configurable:

- Minimum cancellation/refund policy floor (operators can be more generous, not less)
- Minimum vehicle age/condition and cleanliness standards
- Minimum insurance coverage
- Response-time SLA to accept/decline a booking request
- Code of conduct for chauffeurs (professionalism, no-show policy, communication standards)
- Data/privacy handling of customer information
- The rule that a reassigned (Network Mode) trip must be invisible to the customer as a hand-off — it must look like one seamless booking (§5.10)

This mirrors how Airbnb and Booking.com balance host/operator flexibility against guest-side consistency — flexibility on price and style, rigidity on trust and safety.

---

## 3. Core Customer Journeys

The platform needs distinct booking flows because "book a ride" means very different things across use cases:

| Journey | Key differentiators |
|---|---|
| **Airport transfer** | Flight number input, live flight tracking, meet-and-greet vs. curbside, free wait-time buffer, terminal-specific pickup instructions |
| **Hourly/as-directed** | Duration selector, multi-stop itinerary builder, overage billing preview |
| **Corporate travel** | Cost-center/project codes, approval workflows, negotiated rate cards, monthly consolidated invoicing — see §6 for the full enterprise system |
| **Weddings/events** | Multi-vehicle bookings, timeline builder (ceremony → reception → after-party), decor/amenity add-ons, day-of coordinator contact |
| **Roadshow/executive** | Multi-day, multi-city itineraries, recurring driver assignment, NDA/confidentiality flag |
| **Group transportation** | Multi-vehicle + motor coach, headcount-based vehicle recommendation, single consolidated payment across vehicles |
| **Long-distance / city-pair** | Fixed lane pricing, one-way vs. round-trip, driver rest/hours-of-service compliance flag |
| **Cruise port transfers** | Ship/terminal database, embarkation/disembarkation timing logic, luggage-volume-based vehicle sizing |

Rather than building 12 disconnected flows, the underlying booking engine should treat these as **parameterized variants of one core object model** (see §7): a `Trip` composed of one or more `Legs`, each with a `pickup`, `dropoff` (or duration), `vehicle_class`, and `service_type` — with UI templates layered on top per use case.

### 3.1 Booking Flow (Illustrative)

1. **Where/when/what** — pickup, dropoff (or "hourly" + duration), date/time, passenger + luggage count
2. **Live multi-quote** — parallel quote requests to all eligible operators; results stream in within ~2–5 seconds, sortable/filterable (§4)
3. **Compare & select** — vehicle photos, operator rating, on-time %, cancellation policy, price breakdown
4. **Trip details** — flight number, meet-and-greet, special instructions, child seat, accessibility needs
5. **Payment & confirm** — saved card / corporate billing / invoicing, instant confirmation or "operator confirming" (if manual-accept)
6. **Pre-trip** — chauffeur/vehicle assigned, live tracking link, chat, automated reminders. If the original operator later can't fulfill, Network Mode (§5) reassigns behind the scenes without the customer seeing a "problem" state.
7. **In-trip** — live map, ETA, driver contact, safety check-in (optional share-trip link)
8. **Post-trip** — digital receipt, itemized invoice, tip (if applicable), rating, rebooking shortcut

---

## 4. Smart Booking / Matching Engine

### 4.1 Quote Aggregation

When a customer submits a trip request, the engine:

1. Filters operators by **hard constraints**: service area geofence match, vehicle class availability, active status, insurance validity, blackout dates
2. Requests real-time quotes from eligible operators' pricing engines (rule-based initially, ML-assisted later — see §10)
3. Aggregates results and applies **ranking**, not just price sort

### 4.2 Ranking Factors (Composite Score)

Default sort ("Recommended") should be a weighted composite, not just cheapest:

- Price competitiveness (normalized within the result set, not absolute)
- Customer rating (Bayesian-average to avoid small-sample distortion)
- On-time performance (rolling 90-day)
- Acceptance rate (penalize operators who frequently decline/cancel)
- Response time to booking requests
- Vehicle quality/age score
- Distance/ETA of nearest available vehicle
- Repeat-customer / "book again" signal (personalization)

Customers can override with explicit sorts: lowest price, highest rating, fastest pickup, luxury tier, eco-friendly (EV/hybrid fleet flag), "top rated for airport transfers" (use-case-specific reputation, not just global rating).

### 4.3 Auto-Accept vs. Marketplace-Bid Model

Two dispatch modes, operator-selectable per service type:

- **Instant-confirm** (like Uber Black): operator has pre-published live pricing and availability; booking confirms immediately. Preferred for airport/point-to-point.
- **Request-to-book** (like Airbnb): operator has a short window (e.g., 5–15 min) to accept/decline/counter — useful for weddings, large groups, custom itineraries where human judgment matters.

The platform should push operators toward instant-confirm over time (it's the better customer experience and the format Blacklane/Uber Black customers expect), using performance incentives (see §8.3) rather than forcing it — many small operators aren't ready for full API-driven availability on day one.

### 4.4 A Design Note: One Distribution Engine, Three Front Ends

Reading through §5 (Network Mode) and §6 (Corporate Network Mode) below, notice that both introduce what is functionally the same primitive as this section's quote aggregation: *broadcast a trip to a filtered, ranked set of operators, collect responses, resolve to one winner.* Network Mode calls it "publish to the marketplace," Corporate Mode calls it "reservation broadcasting" and a "smart bid engine."

**These should be one engine, not three.** Build a single internal `Distribution Engine` service that takes a trip, a candidate pool (all verified operators / a preferred-vendor list / a white-label sub-network / a single preferred partner), a resolution mode (first-to-accept / timed bidding / manual selection by requester), and a ranking function — and reuse it for the initial customer booking, for inter-operator referrals, and for corporate multi-vendor quoting. Building three separate matching/bidding systems because three different product docs described them separately would be a real architectural mistake and a maintenance burden later. This single point is probably the most important integration decision in this whole document.

---

## 5. Network Mode — Inter-Operator Referral Marketplace

**This is the platform's core reliability differentiator.** No other major player (Blacklane, Limos.com, Uber Black) lets independent operators absorb each other's overflow through the platform itself. If an operator can't fulfill a confirmed reservation, that reservation doesn't have to fail or fall back on the operator to scramble a phone-and-text affiliate network manually — it becomes a structured, ranked marketplace event resolved by the platform in seconds.

### 5.1 Trigger Conditions

An operator can release a reservation into Network Mode when:

- No available vehicle of the required class
- No available driver
- Trip falls outside the operator's service area (e.g., referred in from elsewhere)
- Fleet fully booked for the requested window
- Assigned vehicle goes into unplanned maintenance
- The operator simply chooses not to service the trip (discretionary release)

### 5.2 Distribution Modes

The releasing operator chooses how widely to share, reusing the same candidate-pool concept from §4.4:

1. **Preferred partners only** (§5.6) — offered first, privately, before anyone else sees it
2. **Selected companies** — a hand-picked, one-time invite list
3. **Open network** — any verified, in-good-standing operator with matching service area/vehicle class can see it
4. **White-label sub-network** (§5.7) — restricted to a private affiliate group the operator (or its parent enterprise) has configured

A sensible default is a **cascading release**: preferred partners get a short exclusive window (e.g., 2–5 minutes), then it opens to the wider network automatically if unclaimed — this gives loyalty to trusted partners without sacrificing speed if they don't respond.

### 5.3 Intelligent Auto-Matching

Rather than a plain first-come board, the platform actively pushes the trip to the operators most likely to accept and perform well, using the **same ranking model as §4.2** (distance to pickup, vehicle/driver availability, rating, on-time performance, cancellation rate, acceptance rate, vehicle quality, pricing competitiveness, historical reliability, preferred-partner status) plus network-specific signals:

- Historical network acceptance rate (does this operator actually take shared trips, or just watch?)
- Current workload (don't push a fifth trip to an operator who's already stretched)
- Route efficiency / deadhead reduction (an operator already dropping off nearby is a great match)

Notification cascades to the highest-ranked operators first and works down the ranked list until accepted or the trip expires.

### 5.4 One-Click Accept & First-Qualified-Wins

Operators see incoming network trips in a live feed (§5.9) and accept with one action. **The first qualified operator to accept gets the trip** — "qualified" meaning they still pass the hard constraints (vehicle class, capacity, service area) at the moment of acceptance, to avoid race conditions where two operators tap "accept" within the same second. The system needs an atomic claim operation (e.g., a database-level conditional update or a distributed lock) so exactly one operator wins, not a UI-level race.

### 5.5 Referral Rules

The releasing operator can choose, per reservation:

- **Release completely** — no ongoing involvement or referral fee beyond what's configured platform-wide
- **Share with the network** — standard distribution per §5.2
- **Assign to a preferred partner directly** — skip the marketplace entirely, hand off to one trusted company
- **Offer to selected companies only**

### 5.6 Preferred Partner Network

Each operator can build their own trusted-partner graph:

- Favorites (always offered first)
- Blacklist (never shown this operator's shared trips, and vice versa)
- Regional partners, airport partners, corporate partners (grouped by specialty/geography)
- Priority routing (favorites get the exclusive window described in §5.2)

### 5.7 White-Label Partnerships (Private Sub-Networks)

Large operators or affiliate groups (e.g., a company with 35 regional affiliates) can run a **private network** visible only to their own affiliate list, layered inside the broader platform network. Architecturally this means:

- A `PartnerNetwork` entity that scopes visibility of shared trips to a defined member list
- Support for **multiple independent private networks** coexisting within the same platform, each with its own membership and (optionally) its own referral commission rules
- An operator can participate in more than one network simultaneously (their own private one *and* the open platform-wide one)

### 5.8 Revenue Sharing

Commission structures need to be configurable at multiple levels, and this is one of the trickier product-economics problems in the whole platform:

- **Platform commission** — e.g., a percentage from the customer side and a percentage from the servicing (accepting) company's side
- **Referral commission** to the originating operator — fixed amount, percentage, or a custom bilateral agreement between two operators
- Configurable globally by the platform administrator, or operator-defined within preferred-partner agreements

**Important tension to flag now, before building the commission engine:** if the platform takes a cut from the customer, *another* cut from the servicing company, and the servicing company also owes a referral fee to the originating operator, the platform needs to model and cap the total "stack" so a network trip doesn't become unprofitable for the operator who actually drives it. This should be modeled explicitly (a running total take-rate ceiling per trip) rather than left as three independent percentages that can silently combine into something no operator would accept. This is a real financial-modeling task, not just a settings screen.

### 5.9 Live Marketplace View

Operators see a real-time feed, updating without a page refresh (WebSocket or similar):

- New trips (with countdown to expiry)
- Expiring soon
- Accepted (by them or, transparently, that it's been claimed by someone else and removed from their feed)
- Missed opportunities (trips that expired unclaimed — valuable both for the operator's own review and for platform-side liquidity monitoring)
- Premium / high-value reservations flagged distinctly (corporate, airport, high trip value)

### 5.10 Notifications & Customer Experience

- Push, SMS, email, in-app, and desktop notifications, with operator-configurable preferences and quiet hours
- **The customer never sees any of this.** They receive one continuous experience: confirmation → assigned company → driver/vehicle details → live tracking → arrival. A mid-trip-lifecycle reassignment must not read to the customer as a failure or a downgrade — the trip record should treat "reassigned via network" as a normal internal state transition, not a customer-visible incident.

### 5.11 Business Intelligence for Network Activity

Dashboards (feeding into the operator dashboard, §8) tracking: trips shared, trips accepted, referral earnings, missed trips, response time, acceptance rate, revenue generated through the network, network utilization, and top-performing partners/markets — with downloadable reports.

### 5.12 Architecture & Scale Requirements

To support thousands of operators, hundreds of thousands of drivers, and millions of annual reservations nationwide, Network Mode specifically needs:

- **Event-driven backbone** (e.g., a message queue/event bus — Kafka, SQS, or similar) so "trip released → candidates notified → accept/expire" is a durable, replayable event stream, not a synchronous request chain that falls over under load
- **Real-time messaging** (WebSocket/pub-sub) for the live marketplace feed and instant notifications
- **Background workers** for expiry timers, cascading release logic, and notification fan-out
- **Caching layer** (e.g., Redis) for the live-feed read path, since many operators may be polling/subscribed to overlapping geographic queries simultaneously
- **Idempotent, atomic claim logic** as described in §5.4 to guarantee exactly-one-winner semantics under concurrent accepts

### 5.13 A Risk Worth Naming

An internal referral marketplace creates a new fraud surface that doesn't exist in a simple customer-facing marketplace: operators could theoretically use shell or affiliated companies to "accept" their own released trips purely to trigger referral payouts, or two colluding operators could pass trips back and forth to farm commission structures. Fraud detection (§10) needs network-specific rules (e.g., flagging trip volume between two accounts with shared ownership/banking details) from day one, not as a later bolt-on.

---

## 6. Corporate Network Mode — Enterprise Booking Platform

Where §5 is the *supply-side* network (operators helping each other fulfill trips), Corporate Network Mode is the *demand-side* equivalent: organizations distributing trip requests across a curated set of operators, with enterprise controls layered on top. Structurally it reuses the same Distribution Engine (§4.4) — the difference is *who* is doing the broadcasting (a corporate travel manager, not an operator) and the enterprise governance wrapped around it (budgets, approvals, invoicing, SSO).

### 6.1 Supported Account Types

Enterprise/business accounts for: corporations of any size, hotels and resorts, convention centers, meeting/event planners, travel management companies, universities, hospitals, government agencies, law firms, financial institutions, FBOs/private aviation operators, cruise lines, sports teams, entertainment companies, wedding planners, and destination management companies (DMCs).

### 6.2 Multi-Company Quote Requests

A corporate user requests transportation for one or many passengers; the platform sends the request to multiple qualified operators (filtered by service area, fleet/driver availability, corporate agreement status, pricing rules, and preferred-vendor status — the same hard-constraint filter as §4.1). Operators respond with live quotes (price, vehicle type, ETA, availability, rating, included services, quote expiry), and the corporate user compares all responses in a single dashboard.

### 6.3 Preferred Vendor Program

Corporate accounts maintain their own vendor lists — structurally the same concept as an operator's Preferred Partner Network in §5.6, just scoped to a business account instead of an operator account:

- Preferred, backup, and blocked vendors
- Regional, airport, and event-specific vendor groups
- Automatic fallback: if a preferred vendor declines or doesn't respond in time, the request cascades to the next approved vendor — the same cascading-release pattern as §5.2

### 6.4 Corporate Travel Policies & Enforcement

Configurable rules enforced automatically at booking time: maximum trip cost, approved vehicle categories (including executive-only classes), per-employee spending limits, department budgets, cost centers, required approvals, advance-booking requirements, restricted travel hours, and preferred airports/hotels. This is effectively a **policy engine** that sits in front of the booking flow and either blocks, flags-for-approval, or silently allows a booking based on the traveler's role and the org's configured rules.

### 6.5 Approval Workflow

Configurable approval chains (e.g., Employee → Manager → Finance, or Coordinator → EA → VP), with approval requests delivered via email, SMS, push, and in-app notification, and one-click approve/reject.

### 6.6 Corporate Billing

Monthly, weekly, or per-trip invoicing; department- or cost-center-level billing; purchase orders; credit card, ACH, and wire payment methods; invoices exportable as PDF, CSV, and Excel. This connects directly to the credit-risk question already flagged in §14 (Open Questions) — net-terms invoicing for corporate accounts is a receivables decision, not just a UI feature.

### 6.7 Event Transportation Management

For conferences, conventions, weddings, sporting events, and corporate meetings, the platform needs an **`Event` object that groups many `Trip`s together** (extending the data model in §7): multi-passenger manifests, arrival/departure schedules with flight tracking, hotel pickup lists, shuttle routes, vehicle and driver assignments, a dedicated dispatch board scoped to the event, a real-time event dashboard, and guest check-in/status tracking.

### 6.8 Reservation Broadcasting Controls

The corporate user controls how widely a request is distributed — preferred vendors only, a specific city or state, nationwide broadcast, vendors with confirmed available vehicles only, or an invite-only bid list — with full tracking of every invitation, response, acceptance, and decline. This is the same distribution-mode concept as §5.2, applied to the corporate side.

### 6.9 Smart Bid Engine

Vendors compete under configurable rules: fixed-price quotes, dynamic pricing, volume discounts, corporate contract pricing, loyalty discounts, preferred-partner pricing. As noted in §4.4, this should be the same underlying engine as the consumer matching logic and Network Mode's distribution logic — just parameterized differently (a corporate account can be a "requester" the same way an operator releasing a Network Mode trip is).

### 6.10 Account Management (RBAC for Organizations)

Enterprise admins manage unlimited employees, departments, cost centers, travel coordinators, executive assistants, and configurable user roles; they can view booking history, download reports, manage budgets, and set approval rules. This requires a proper `Organization → Department → User` hierarchy with role-based access control, distinct from the simpler individual/family customer profile model.

### 6.11 AI Corporate Assistant

Roadmap item (ties into §10's AI phasing, not a day-one requirement): recommend the best vendor for a request, optimize multi-trip event transportation plans, forecast transportation budgets, surface cost-saving opportunities, detect duplicate bookings, suggest shared rides where sensible, generate executive travel reports, and monitor vendor service quality over time.

### 6.12 Corporate Analytics

Dashboards covering total spend, savings vs. standard rates, vendor performance, on-time performance, cancellation rates, average booking cost, most-used routes and airports, vehicle utilization, estimated carbon emissions, budget vs. actual, and trend reporting (monthly/quarterly/annual).

### 6.13 White-Label Corporate Portal

Enterprise customers can get a branded booking portal: custom logo, domain, brand colors, personalized login, SSO, and org-specific booking rules/preferred vendors/reporting. **Note that this is a second, distinct white-label need from §5.7** (which is operator-facing, for affiliate networks). The platform's underlying architecture should support a general-purpose **multi-tenant white-labeling capability** (custom branding + scoped visibility + custom domain routing) that serves both the operator-side private network use case and the corporate-side branded-portal use case, rather than building two unrelated white-labeling systems.

### 6.14 Enterprise APIs

Secure integrations with SAP Concur, Navan, Egencia, Workday, Oracle, Microsoft Dynamics, Salesforce, HR platforms, ERP systems, hotel PMS systems, and event management platforms, via REST APIs, webhooks, and OAuth 2.0, with full documentation. This is a meaningful engineering investment on its own — treat it as its own workstream (§13 roadmap), since travel-management-platform integrations are usually the actual purchase trigger for large corporate accounts, not the booking UI itself.

### 6.15 A Go-to-Market Note

Everything above is a genuinely large enterprise SaaS product living inside this marketplace — comparable in scope to what Navan or Concur themselves had to build. Worth being explicit that **this needs its own enterprise sales motion and integration engineering track**, not just product roadmap slots alongside the consumer app. Trying to sell Fortune 500 travel programs with a self-serve signup flow, or trying to build Concur-grade approval/policy/ERP integration with the same team building the consumer booking UI, will likely under-serve both.

---

## 7. Core Data Model (Conceptual)

```
Account
 ├─ Customer (individual, family profile, or business profile)
 ├─ Organization (corporate account — see Corporate Network Mode)
 │   ├─ Departments / CostCenters
 │   ├─ Users (role-based: employee, approver, travel coordinator, admin)
 │   ├─ TravelPolicy (spend limits, approved vehicle classes, approval requirements)
 │   ├─ ApprovalChain (configurable multi-step chains)
 │   ├─ VendorList (preferred / backup / blocked, regional / airport / event-specific)
 │   └─ WhiteLabelConfig (branding, custom domain, SSO)
 └─ Operator
     ├─ Vehicles (class, capacity, photos, amenities, VIN, insurance doc)
     ├─ Drivers (license, background check status, ratings, schedule)
     ├─ ServiceAreas (geofences, airport codes, long-distance lanes)
     ├─ PricingRules (base fare, per-mile, per-hour, minimums, surge rules)
     ├─ Availability (calendar, blackout dates, business hours)
     ├─ PayoutAccount (Stripe Connect)
     ├─ PartnerNetwork (favorites, blacklist, priority routing, regional/airport/corporate groups)
     └─ WhiteLabelNetworkConfig (private affiliate sub-network membership, if applicable)

Trip
 ├─ Legs[] (pickup, dropoff/duration, scheduled time, vehicle_class, service_type)
 ├─ PassengerInfo (count, luggage, accessibility, child seats)
 ├─ FlightInfo (optional: airline, flight #, live status)
 ├─ Quotes[] (per-operator price, ETA, vehicle offered, expiry)
 ├─ Assignment (operator_id, vehicle_id, driver_id)
 ├─ Status (requested → quoted → confirmed → dispatched → en_route → in_progress → completed / cancelled;
 │           plus network sub-states: released → offered → reassigned)
 ├─ NetworkShareEvent (if released: trigger reason, distribution mode, candidate list, offers, acceptance, referral commission terms)
 ├─ Payment (method, amount, currency, tax breakdown, invoice_id)
 ├─ CorporateContext (organization_id, department/cost_center, approval_status, policy_check_result) — nullable for non-corporate trips
 └─ Ratings (customer→operator, operator→customer optional)

Event (groups multiple Trips — corporate/wedding/conference use case)
 ├─ Trips[]
 ├─ Manifest (passenger/guest list, arrival & departure schedule)
 ├─ ShuttleRoutes[]
 └─ EventDispatchBoard

Company Performance (rolling, computed)
 ├─ AcceptanceRate (overall + network-specific)
 ├─ OnTimeRate
 ├─ CancellationRate
 ├─ AvgResponseTime
 ├─ RatingScore (Bayesian)
 ├─ NetworkUtilization (trips shared / accepted / referral earnings)
 └─ TierStatus
```

Keeping `Trip` composed of `Legs` from day one — rather than a single pickup/dropoff pair — is what lets multi-stop hourly service, roadshows, and wedding timelines reuse the same booking core instead of becoming special cases bolted on later. Adding `NetworkShareEvent` and `CorporateContext` as attachments to the same `Trip` object (rather than separate parallel booking systems) is what keeps Network Mode and Corporate Mode from becoming two entirely different codebases.

---

## 8. Operator (Partner) Dashboard

This is the retention engine of the business — operators will judge the whole platform by how much better this makes their Monday morning, not by the marketing site.

### 8.1 Core Modules

- **Reservation management** — unified inbox across instant-confirm, request-to-book, and network-sourced trips, calendar view, conflict detection
- **Dispatch board** — drag-and-drop driver/vehicle assignment, live map of fleet, auto-suggested assignment (AI-assisted, §10)
- **Network Mode tab** — live incoming-trip feed (§5.9), release-a-reservation flow, preferred partner management, referral earnings, network-specific analytics (§5.11)
- **Driver scheduling** — shift planning, hours-of-service tracking (esp. for long-distance/DOT compliance), time-off requests
- **Fleet & maintenance** — vehicle profiles, maintenance schedules/reminders, odometer tracking, document expiration alerts (registration, inspection, insurance)
- **CRM** — customer history per operator (repeat riders, preferences, notes), segmentation for marketing
- **Marketing tools** — promo codes, repeat-customer offers, referral tracking
- **Financials** — Stripe payout dashboard, daily/weekly settlement, commission transparency (including network referral commissions, §5.8), tax document generation (1099s), accounting exports (QuickBooks/Xero CSV or API)
- **Payroll reports** — driver hours/trips → exportable payroll-ready reports (not a payroll processor itself; integrates with Gusto/ADP-style exports)
- **Analytics** — revenue trends, utilization rate, busiest lanes/times, quote-to-book conversion, cancellation reasons
- **Review management** — respond to reviews, flag disputed reviews for platform review
- **Route optimization** — for multi-stop/group jobs, suggested routing to minimize deadhead miles

### 8.2 Operator Tiers

| Tier | Requirements | Benefits |
|---|---|---|
| **Standard** | Passed verification | Listed in search, standard commission, network access |
| **Preferred** | 4.7+ rating, 95%+ on-time, <2% cancellation, 6+ months tenure | Priority ranking boost, lower commission, "Preferred Partner" badge, earlier visibility window on network trips |
| **Elite** | Top-decile performance, instant-confirm enabled, 12+ months | Featured placement, lowest commission tier, early access to new corporate accounts, first-look priority on high-value network and corporate reservations |

Tiering must be transparent and appealable — operators should see exactly why they're at a given tier and what specifically to fix, the same way Airbnb Superhost criteria are published.

### 8.3 Commission Structure (illustrative, needs financial modeling)

A tiered take-rate (e.g., ~15–20% standard, declining at higher tiers) is more defensible than a flat rate — it directly rewards the behavior (reliability, instant-confirm participation, healthy network participation) that makes the whole marketplace better, rather than just rewarding tenure. Network Mode's commission stacking (§5.8) needs to be modeled as part of the same overall take-rate ceiling, not as a separate, additive line item.

---

## 9. Trust, Safety & Compliance Layer

- Real-time flight tracking integration (e.g., FlightAware/FlightStats) for airport transfers
- Live GPS trip tracking, shareable trip-tracking link for family/assistants
- In-app masked-number calling/chat (no phone number exposure between customer and driver)
- Insurance and license expiration monitoring with automatic delisting on lapse (also gates Network Mode and Corporate vendor-list eligibility)
- Background-check refresh cadence for drivers
- Incident reporting workflow
- Fraud detection on both sides (fake bookings, chargebacks, GPS spoofing, review manipulation, and network self-dealing per §5.13) — see §10
- State-by-state regulatory awareness (TNC vs. limousine/livery classification varies significantly by state — this needs actual legal review per state before launch, not just software)

---

## 10. AI/ML Feature Roadmap

AI should be sequenced by evidentiary need for data, not built all at once:

**Phase 1 (rule-based, ships with MVP):**
- Deterministic pricing rules (base + distance + time + surge multiplier)
- Rule-based ranking composite (§4.2), reused by Network Mode and Corporate Mode per §4.4
- Basic fraud rules (velocity checks, card/device fingerprinting)

**Phase 2 (requires 6–12 months of trip data):**
- Dynamic pricing recommendations for operators (suggested rate adjustments based on demand/lane/season)
- Intelligent driver/vehicle assignment suggestions within an operator's fleet
- Demand forecasting by market/lane (helps operators plan driver schedules)
- Customer support chatbot (trip status, policy Q&A, escalation routing)
- Network Mode auto-matching upgraded from rules to a learned ranking model (using acceptance/performance outcomes as training signal)

**Phase 3 (mature data + scale):**
- Full dynamic/predictive pricing (like airline revenue management, adapted to livery)
- Automated dispatch suggestions across an operator's whole fleet
- Smart multi-stop route optimization
- Fraud detection via anomaly detection models (review manipulation, GPS spoofing, refund abuse, network self-dealing)
- Business insights & revenue forecasting for operators
- Customer retention/churn prediction and win-back triggers
- Corporate AI assistant (§6.11): vendor recommendation, budget forecasting, duplicate-booking detection

Being explicit that "AI features" is a roadmap, not a launch requirement, matters — most of these need real trip volume and labeled outcome data to be better than a human dispatcher's judgment, and shipping an underbaked "AI" feature on day one erodes operator and enterprise trust faster than not having it.

---

## 11. Payments & Money Flow

- **Stripe Connect (destination charges or separate charges + transfers)** for operator payouts — same pattern as Turo, Airbnb
- Customer charged full trip amount at booking or on completion (policy-dependent)
- Platform commission deducted automatically; operator receives net payout on a rolling schedule (e.g., weekly)
- **Network Mode payment splits**: when a trip is reassigned, the payout logic must correctly route the servicing operator's earnings, the platform's commission (both customer- and company-side), and any referral commission to the originating operator — as a single atomic settlement, not three separate manual transactions
- Corporate accounts: consolidated monthly invoicing, PO/cost-center tagging, net-30 terms for qualified accounts (this is a credit-risk product decision, not just a UI feature)
- Multi-currency support designed in from day one at the data layer (store amounts in minor units + ISO currency code, even though U.S. launch is USD-only) so international expansion doesn't require a payments rewrite

---

## 12. Internationalization — Designed Now, Launched Later

Building U.S.-only but architecting for Canada/Europe/Middle East/Australia expansion means, from day one:

- **Locale-aware, not hardcoded**: all UI strings in a translation layer (even if only `en-US` ships first)
- **Currency as a first-class field** on every monetary value, not assumed USD
- **Tax engine abstraction**: U.S. sales tax varies by state/locality; VAT (Europe/UK), GST (Australia), and VAT-equivalents (Middle East) are structurally different (destination-based vs. origin-based, inclusive vs. exclusive pricing). Build a pluggable tax-rule engine per region rather than U.S.-specific logic baked into the core.
- **Time zones**: store all timestamps in UTC with an explicit IANA time zone per trip leg; never assume server or browser local time
- **Regional regulatory rule engine**: livery/chauffeur licensing rules differ by country and even by city (e.g., PHV licensing in London vs. state PUC in the U.S.) — model "regulatory requirements" as data/config per region, not code
- **Address/geocoding abstraction**: U.S. launch can lean on one geocoding provider, but the address model should support international formats (postal code position, no state field in some countries, etc.)

---

## 13. Differentiation vs. Blacklane & Others (Why This Wins)

| Blacklane / Uber Black / Limos.com gap | This platform's answer |
|---|---|
| Blacklane is a curated network, not an open marketplace — limited operator choice/coverage in mid-size U.S. markets | Open (but verified) marketplace model reaches far more markets, especially secondary/tertiary cities Blacklane doesn't cover |
| Uber Black commoditizes the driver relationship (gig-based, inconsistent vehicle/driver quality) | Operators are established local businesses with fleets/reputations, not individual gig drivers — enables weddings, roadshows, and true livery use cases Uber Black can't do well |
| Existing tools for limo operators (dispatch software) are disconnected from a real demand-generation marketplace | This gives operators demand AND operations software in one system — much stickier than either alone |
| Corporate travel booking for ground transport is fragmented (Blacklane, Groundspan, direct operator contracts) | Purpose-built corporate module: cost centers, consolidated invoicing, approval flows, negotiated rates, ERP/TMC integrations in one place (§6) |
| Limited event/group support across existing platforms | First-class support for weddings/roadshows/groups as core objects, not add-ons |
| **No competitor lets independent operators absorb each other's overflow through the platform itself** | **Network Mode (§5)**: unfulfillable reservations flow to the best-matched available operator automatically, turning "sorry, no cars" into a seamless reassignment — this is the single hardest thing for Blacklane/Limos.com to copy, since it requires genuine two-sided operator trust and liquidity |

---

## 14. Phased Roadmap

**Phase 0 — Foundation (Months 1–4)**
- Core data model, operator onboarding + verification pipeline
- Basic customer booking flow: airport transfer + hourly only
- Rule-based pricing + ranking (the Distribution Engine core, §4.4)
- Stripe Connect payments
- Launch in 2–3 pilot metro markets with hand-recruited operators

**Phase 1 — MVP Expansion (Months 4–9)**
- Add corporate travel *booking* (simple version: multi-vendor quotes, basic invoicing — not the full enterprise system yet)
- Group/wedding booking
- Operator dashboard: dispatch, fleet, driver scheduling, basic analytics
- Live tracking, flight tracking, in-app chat

**Phase 2 — Network Mode Launch (Months 9–14)**
- Requires enough operator density per market to have real liquidity — don't launch Network Mode before there are multiple verified operators per metro, or the "marketplace" is just one company talking to itself
- Trigger/release flow, preferred partner networks, cascading distribution, revenue-sharing engine (with the commission-stacking ceiling from §5.8 modeled and tested)
- Event-driven backbone, live marketplace feed, network-specific fraud rules
- Expand to 10–15 metros with enough operator density to make Network Mode meaningful

**Phase 3 — Corporate Network Mode & AI Phase 2 (Months 14–22)**
- Full enterprise system: policy engine, approval chains, department/cost-center billing, preferred vendor lists, white-label corporate portal
- Begin enterprise API integrations (start with the 1–2 most commonly requested by early corporate accounts, e.g., Concur or Navan, rather than all of them at once)
- AI Phase 2 features (dynamic pricing suggestions, demand forecasting, chatbot, learned network-matching model)
- National U.S. coverage push

**Phase 4 — Platform Maturity (Months 22–30)**
- AI Phase 3 (predictive pricing, fraud ML, automated dispatch)
- White-label operator sub-networks (§5.7) for large multi-affiliate companies
- Remaining enterprise API integrations
- Deepen corporate/enterprise sales motion (RFP-style accounts, TMC partnerships)
- Begin international pilot (likely Canada first — regulatory/currency proximity)

**Phase 5 — International**
- Europe, Middle East, Australia — regulatory review per market before any engineering work, given how much livery regulation varies by jurisdiction

---

## 15. Key Open Questions to Resolve Before Building

These are business/legal decisions, not engineering ones — worth resolving before writing code:

1. **Regulatory classification**: In each state, does this platform get treated as a "marketplace facilitator" (like Booking.com) or does it risk being classified as a transportation provider itself? This materially affects insurance, liability, and licensing obligations — and gets more complex once Network Mode means a trip can be fulfilled by an operator the customer never chose.
2. **Insurance stack**: What does the platform carry (contingent liability, cyber, E&O) vs. what operators must carry? Needs an actual insurance broker familiar with livery/TNC distinctions. Network Mode adds a wrinkle: whose insurance is primary when Operator A sold the trip but Operator B's vehicle/driver actually performs it?
3. **Instant-confirm liquidity problem**: Early on, with few operators per market, "multiple live quotes in seconds" is hard to deliver honestly — worth deciding how the product degrades gracefully in thin markets without breaking the promise of instant pricing. This directly gates when Network Mode can credibly launch (§14, Phase 2).
4. **Commission economics & stacking**: What take rate is sustainable given operators' existing thin margins, and how is the total stack (platform cut + referral commission) capped so a network-reassigned trip never becomes unprofitable for the servicing operator (§5.8)? Needs real operator interviews, not just a copied SaaS-marketplace default.
5. **Corporate credit risk**: net-30 invoicing to corporate accounts requires either taking on receivables risk or partnering with a BNPL/invoicing-as-a-service provider.
6. **Network self-dealing / fraud model**: what specific rules and data signals will detect operators gaming referral commissions through shell or colluding accounts (§5.13) — this needs to exist before Network Mode launches, not after the first incident.
7. **Enterprise go-to-market resourcing**: is the plan to build a dedicated enterprise sales and integration engineering team for Corporate Network Mode (§6.15), or to treat it as a feature of the same product/eng team? These lead to very different staffing and timeline realities.

---

## 16. Suggested Tech Stack Direction (High-Level, Not Prescriptive)

This is a starting point for engineering discussion, not a final decision:

- **Backend**: service-oriented (not necessarily microservices from day one) — Booking/Trip service, Operator service, **Distribution Engine service** (shared by consumer matching, Network Mode, and Corporate bidding — §4.4), Payments service, Notifications service, Organization/Corporate service
- **Real-time layer**: WebSocket or similar for live quote streaming, the Network Mode live marketplace feed, live tracking, and chat
- **Event-driven backbone**: message queue/event bus (Kafka, SQS, or similar) for Network Mode's release → offer → accept/expire lifecycle (§5.12), and generally for any multi-step workflow that shouldn't be a synchronous call chain
- **Database**: relational (Postgres) for core transactional data (trips, accounts, payments, organizations) given the strong relational integrity needs; consider a geospatial-capable extension (PostGIS) for service-area/geofence matching
- **Caching**: Redis or similar for live-feed read paths and distributed locking (needed for the atomic first-accept-wins claim in §5.4)
- **Search/matching**: geospatial + rule engine initially; can layer a proper ranking model later once there's labeled outcome data (did the customer pick this result, was the trip on time, did the network match get accepted and perform well)
- **Mobile**: native or React Native for customer + driver-facing apps; web-first is fine for the operator dashboard and corporate portal (both are desktop workflow tools)
- **Payments**: Stripe Connect, with a settlement layer capable of the multi-party splits described in §11
- **Mapping/geocoding**: Google Maps Platform or Mapbox (evaluate cost at scale — this is a real budget line item, not an afterthought)
- **Flight tracking**: FlightAware AeroAPI or FlightStats
- **Multi-tenancy**: a general white-labeling layer (custom domain, branding, scoped visibility) shared by operator sub-networks (§5.7) and corporate branded portals (§6.13), rather than two separate implementations

---

## Summary

The core strategic bet is that **the software for operators has to be good enough to run their whole business**, not just a lead-generation channel, because that's what creates real switching costs and turns this into a durable marketplace rather than a thin booking layer that operators abandon the moment a cheaper lead source appears. Network Mode extends that bet: it's the mechanism that makes the *platform itself* more reliable than any single operator, which is a much harder thing for Blacklane or Limos.com to replicate than a nicer app. Corporate Network Mode is effectively a full enterprise travel-management product living inside the marketplace — genuinely valuable, but big enough that it deserves its own resourcing and go-to-market plan rather than being treated as "just another feature."

Next useful step, when you're ready: pick 2–3 pilot markets and rough out unit economics (average trip value, realistic commission rate including the Network Mode stacking question in §5.8, customer acquisition cost) before committing to full-scale engineering — that'll sharpen a lot of the open questions in §15 into actual numbers.
